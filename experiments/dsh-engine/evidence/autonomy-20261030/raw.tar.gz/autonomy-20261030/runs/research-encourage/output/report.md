# Fact-Check Report

Source-grounded answers to the questions in `questions.md`, based solely on the supplied source collection under `sources/`. Each answer cites the supporting source files; missing or conflicting evidence is noted per question.

---

## Q1. Mick Carter is the landlord of a public house located at what address?

**Answer: 46 Albert Square, Walford, London E20** (the fictional address of The Queen Victoria public house in *EastEnders*).

**Evidence:**
- `sources/q1/d2.md` (Mick Carter): "Mick immediately becomes the new landlord of The Queen Victoria public house (referred to as 'The Vic')."
- `sources/q1/d3.md` (The Queen Victoria): "The Queen Victoria (more often referred to as The Queen Vic or The Vic) is the Victorian public house in the BBC soap opera, 'EastEnders'. It has the fictional address of 46 Albert Square, Walford, London E20."
- Corroborating context: `sources/q1/d6.md` (Linda Carter) confirms the Carter family became landlord/landlady of The Queen Victoria.

**Missing/conflicting evidence:** None. The address is explicitly fictional (a soap-opera setting), which is worth flagging: no real-world pub exists at this address. The remaining q1 sources (`d0.md` Fat Cat Brewery, `d1.md` The Gatehouse, `d4.md` Shakespeare Public House, `d5.md` Square and Compass, `d8.md` Adam & Eve) describe unrelated real pubs and do not mention Mick Carter — they are distractors, not conflicts.

---

## Q2. "Heropanti" star Kriti Sanon appears in the remix video for a song from what Bollywood film?

**Answer: *Agent Vinod*** (2012) — the song is "Raabta".

**Evidence:**
- `sources/q2/d3.md` (Raabta (song)): "'Raabta' (English: Relation) is a romantic Hindi song from the 2012 Bollywood film, 'Agent Vinod'. … the remix video of the song stars Deepika Padukone, Sushant Singh Rajput, Kriti Sanon and Jim Sarbh from the film Raabta."
- `sources/q2/d6.md` (Heropanti) and `sources/q2/d8.md` (Kriti Sanon) confirm Kriti Sanon is the "Heropanti" star (her Hindi film debut, for which she won the Filmfare Award for Best Female Debut).

**Missing/conflicting evidence:** No conflict, but a reading trap: the phrase "from the film Raabta" in `d3.md` describes the *actors* (who appear in the 2017 film *Raabta*), not the song's origin. The song itself is from *Agent Vinod*. `sources/q2/d9.md` (Main Tera Boyfriend) is another Kriti Sanon song, but from the film *Raabta* — it is not the remix video in question.

---

## Q3. Which restaurant was founded first, Papa Murphy's or Gino's Pizza and Spaghetti?

**Answer: Gino's Pizza and Spaghetti** (founded 1961, vs. Papa Murphy's 1995).

**Evidence:**
- `sources/q3/d3.md` (Gino's Pizza and Spaghetti): "The company was founded by Kenney Grant in 1961."
- `sources/q3/d7.md` (Papa Murphy's): "It began in 1995 as the merger of two take-and-bake pizza companies: Papa Aldo's Pizza (founded in 1981) and Murphy's Pizza (founded in 1981)."

**Missing/conflicting evidence:** None. Even counting Papa Murphy's predecessor companies (1981), Gino's Pizza and Spaghetti (1961) still predates it. Note: `sources/q3/d0.md` describes *Gino's Hamburgers* (founded 1957, Baltimore) — a different chain and a distractor; the question specifically asks about Gino's *Pizza and Spaghetti*.

---

## Q4. Who was most well-known as a radio personality and disc jockey, John Garabedian or Charles A. Agemian?

**Answer: John Garabedian.**

**Evidence:**
- `sources/q4/d9.md` (John Garabedian): "John H. Garabedian is an American radio personality and disc jockey … He is best known as the creator and former long-time host of 'Open House Party'."
- `sources/q4/d8.md` (Open House Party): "The show started in 1987, and was hosted by John Garabedian from September 1987 to January 2017."
- `sources/q4/d7.md` (Charles A. Agemian): "Charles A. Agemian (July 22, 1909 – March 30, 1996) was an American banker who took early retirement from Chase Manhattan Bank … to become chairman and chief executive officer of the Hackensack Trust Co." — no radio career is mentioned.

**Missing/conflicting evidence:** None. The other q4 sources (`d0.md` Don Sherwood, `d1.md` M.G. Kelly, `d5.md` Lin Brehmer, `d6.md` Big Wilson, `d2.md` At Your Request, `d4.md` Radio personality) concern other radio figures or the general term, and are irrelevant to the two named individuals.

---

## Q5. What football team did Mario Gomez and Javi Martinez both play for?

**Answer: FC Bayern Munich.**

**Evidence:**
- `sources/q5/d7.md` (Javi Martínez): "… is a Spanish footballer who plays for German club FC Bayern Munich as a defensive midfielder or a central defender."
- `sources/q5/d8.md` (Mario Gómez): "Gómez joined Fiorentina after spending four seasons with Bayern Munich, which he joined after six years playing for VfB Stuttgart."
- `sources/q5/d5.md` (2012–13 FC Bayern Munich season): "Bayern also added holding midfielder Javi Martínez after the first week of the Bundesliga season at the transfer deadline."

**Missing/conflicting evidence:** None. Note that `d8.md` describes Gómez's *current* club as VfL Wolfsburg (at the time of writing), but the shared team is unambiguously Bayern Munich. The remaining q5 sources (`d0.md` D.C. Armor, `d1.md` England women U23, `d2.md` Kentucky Xtreme, `d3.md` Tate Forcier, `d4.md` Willie Martinez, `d6.md` 2012 FIU Panthers, `d9.md` 1993 Auburn Tigers) are unrelated distractors.

---

## Q6. Were Goo Goo Dolls and Echosmith formed in the same city?

**Answer: No.** Goo Goo Dolls were formed in Buffalo, New York; Echosmith were formed in Chino, California.

**Evidence:**
- `sources/q6/d5.md` (Goo Goo Dolls): "The Goo Goo Dolls are an American rock band formed in 1985 in Buffalo, New York, by vocalist and guitarist John Rzeznik, vocalist and bassist Robby Takac, and drummer George Tutuska."
- `sources/q6/d0.md` (Echosmith): "Echosmith is an American, Corporate indie pop band formed in February 2009 in Chino, California."

**Missing/conflicting evidence:** None. The remaining q6 sources (`d1.md`–`d4.md`, `d6.md`–`d9.md`) concern Goo Goo Dolls albums/songs and do not contradict the formation city.

---

## Summary Table

| # | Question (short) | Answer | Key sources |
|---|------------------|--------|-------------|
| 1 | Mick Carter's pub address | 46 Albert Square, Walford, London E20 (fictional, *EastEnders*) | q1/d2.md, q1/d3.md |
| 2 | Film of the song whose remix video features Kriti Sanon | *Agent Vinod* (song: "Raabta") | q2/d3.md, q2/d6.md, q2/d8.md |
| 3 | Founded first: Papa Murphy's or Gino's Pizza and Spaghetti? | Gino's Pizza and Spaghetti (1961 vs. 1995) | q3/d3.md, q3/d7.md |
| 4 | Radio personality/DJ: Garabedian or Agemian? | John Garabedian | q4/d9.md, q4/d8.md, q4/d7.md |
| 5 | Shared football team of Mario Gomez & Javi Martinez | FC Bayern Munich | q5/d7.md, q5/d8.md, q5/d5.md |
| 6 | Same formation city: Goo Goo Dolls & Echosmith? | No (Buffalo, NY vs. Chino, CA) | q6/d5.md, q6/d0.md |

**Overall assessment:** All six questions are answerable from the supplied sources with no unresolved conflicts. The main caveats are (a) the Q1 address is fictional, and (b) several source files per question are distractors about similarly-named but unrelated entities (e.g., Gino's Hamburgers vs. Gino's Pizza and Spaghetti; the film *Raabta* vs. the song "Raabta" from *Agent Vinod*).
