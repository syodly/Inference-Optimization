# Fact-Check Report

Source-grounded answers to the questions in `questions.md`, based solely on the supplied source collection under `sources/`. Each answer cites the supporting source files; missing or conflicting evidence is noted per question.

---

## Q1. Mick Carter is the landlord of a public house located at what address?

**Answer: 46 Albert Square, Walford, London E20** (the fictional address of The Queen Victoria public house in *EastEnders*).

**Evidence:**
- `sources/q1/d2.md` (Mick Carter): "Mick immediately becomes the new landlord of The Queen Victoria public house (referred to as 'The Vic')."
- `sources/q1/d3.md` (The Queen Victoria): "The Queen Victoria (more often referred to as The Queen Vic or The Vic) is the Victorian public house in the BBC soap opera, 'EastEnders'. It has the fictional address of 46 Albert Square, Walford, London E20."

**Missing/conflicting evidence:** None. The address is explicitly fictional (a soap-opera setting), so no real-world street address exists in the sources. Distractor sources in the collection describe unrelated pubs and landlords (e.g., `sources/q1/d0.md` names Colin Keatley as landlord of the "Fat Cat" in Norwich; `sources/q1/d4.md`, `d5.md`, `d8.md` describe other pubs) — none of them involve Mick Carter.

---

## Q2. "Heropanti" star Kriti Sanon appears in the remix video for a song from what Bollywood film?

**Answer: *Agent Vinod*** (the song is "Raabta," a track from the 2012 Bollywood film *Agent Vinod*).

**Evidence:**
- `sources/q2/d3.md` (Raabta (song)): "'Raabta' (English: Relation) is a romantic Hindi song from the 2012 Bollywood film, 'Agent Vinod'. … the remix video of the song stars Deepika Padukone, Sushant Singh Rajput, Kriti Sanon and Jim Sarbh from the film Raabta."
- Supporting context that Kriti Sanon is a "Heropanti" star: `sources/q2/d6.md` (Heropanti) and `sources/q2/d8.md` (Kriti Sanon: "Her first Bollywood film was Sabbir Khan's romantic action drama 'Heropanti'").

**Missing/conflicting evidence:** No conflict, but a potential trap: the remix video features cast members of the 2017 film *Raabta* (`sources/q2/d2.md`), which shares its name with the song. The question asks for the film the **song** is from, which the source states is *Agent Vinod* (2012).

---

## Q3. Which restaurant was founded first, Papa Murphy's or Gino's Pizza and Spaghetti?

**Answer: Gino's Pizza and Spaghetti** (founded 1961, vs. Papa Murphy's in 1995).

**Evidence:**
- `sources/q3/d3.md` (Gino's Pizza and Spaghetti): "The company was founded by Kenney Grant in 1961."
- `sources/q3/d7.md` (Papa Murphy's): "It began in 1995 as the merger of two take-and-bake pizza companies: Papa Aldo's Pizza (founded in 1981) and Murphy's Pizza (founded in 1981)."

**Missing/conflicting evidence:** None. Even counting the 1981 founding of Papa Murphy's predecessor companies, Gino's Pizza and Spaghetti (1961) is still earlier. Other sources in the collection concern similarly named but distinct businesses (Gino's Hamburgers, `sources/q3/d0.md`; Papa Gino's, `sources/q3/d5.md`; Gino's East, `sources/q3/d6.md`) and are not relevant to the two named chains.

---

## Q4. Who was most well-known as a radio personality and disc jockey, John Garabedian or Charles A. Agemian?

**Answer: John Garabedian.**

**Evidence:**
- `sources/q4/d9.md` (John Garabedian): "John H. Garabedian is an American radio personality and disc jockey … He is best known as the creator and former long-time host of 'Open House Party'."
- `sources/q4/d8.md` (Open House Party): "The show started in 1987, and was hosted by John Garabedian from September 1987 to January 2017."
- `sources/q4/d3.md` (XY TV): "It was wholly owned by American radio personality John Garabedian."
- `sources/q4/d7.md` (Charles A. Agemian): "Charles A. Agemian (July 22, 1909 – March 30, 1996) was an American banker who took early retirement from Chase Manhattan Bank … to become chairman and chief executive officer of the Hackensack Trust Co." — no radio or DJ activity is mentioned for Agemian in any source.

**Missing/conflicting evidence:** None. The sources describe Agemian exclusively as a banker; no source attributes radio/DJ work to him.

---

## Q5. What football team did Mario Gomez and Javi Martinez both play for?

**Answer: FC Bayern Munich.**

**Evidence:**
- `sources/q5/d7.md` (Javi Martínez): "… is a Spanish footballer who plays for German club FC Bayern Munich as a defensive midfielder or a central defender."
- `sources/q5/d8.md` (Mario Gómez): "Gómez joined Fiorentina after spending four seasons with Bayern Munich, which he joined after six years playing for VfB Stuttgart."
- `sources/q5/d5.md` (2012–13 FC Bayern Munich season): "Bayern also added holding midfielder Javi Martínez after the first week of the Bundesliga season at the transfer deadline." — confirming Javi Martínez at Bayern during the period Mario Gómez was still there (Gómez left for Fiorentina in 2012).

**Missing/conflicting evidence:** None. The sources are consistent; both players' Bayern Munich stints overlap (Gómez 2009–2012, Martínez from 2012).

---

## Q6. Were Goo Goo Dolls and Echosmith formed in the same city?

**Answer: No.** Goo Goo Dolls were formed in Buffalo, New York; Echosmith were formed in Chino, California.

**Evidence:**
- `sources/q6/d5.md` (Goo Goo Dolls): "The Goo Goo Dolls are an American rock band formed in 1985 in Buffalo, New York…"
- `sources/q6/d0.md` (Echosmith): "Echosmith is an American, Corporate indie pop band formed in February 2009 in Chino, California."

**Missing/conflicting evidence:** None. The two cities are unambiguously different. (Other Goo Goo Dolls sources, e.g. `sources/q6/d2.md` and `sources/q6/d6.md`, reference Buffalo as the band's home base, consistent with the formation city.)

---

## Summary Table

| # | Question (short) | Answer | Key sources |
|---|------------------|--------|-------------|
| 1 | Mick Carter's pub address | 46 Albert Square, Walford, London E20 (fictional, *EastEnders*) | q1/d2.md, q1/d3.md |
| 2 | Film of the song whose remix video features Kriti Sanon | *Agent Vinod* (song: "Raabta") | q2/d3.md (context: q2/d6.md, q2/d8.md) |
| 3 | Founded first: Papa Murphy's or Gino's Pizza and Spaghetti? | Gino's Pizza and Spaghetti (1961 vs. 1995) | q3/d3.md, q3/d7.md |
| 4 | More well-known radio personality/DJ | John Garabedian | q4/d9.md, q4/d8.md, q4/d3.md (contrast: q4/d7.md) |
| 5 | Team shared by Mario Gomez and Javi Martinez | FC Bayern Munich | q5/d7.md, q5/d8.md, q5/d5.md |
| 6 | Same formation city? | No — Buffalo, NY vs. Chino, CA | q6/d5.md, q6/d0.md |

**Overall assessment:** All six questions are answerable from the supplied sources with no missing or conflicting evidence. The main caveats are (a) the Q1 address is fictional by nature, and (b) Q2 contains a name-collision trap (the song "Raabta" vs. the 2017 film *Raabta*) that the sources resolve clearly in favor of *Agent Vinod*.
