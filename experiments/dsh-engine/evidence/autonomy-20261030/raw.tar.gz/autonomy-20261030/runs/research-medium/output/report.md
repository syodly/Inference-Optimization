# Fact-Check Report

Source-grounded answers to the six questions in `questions.md`, based exclusively on the supplied source collection (`sources/q1/` … `sources/q6/`). Citations refer to the source filenames.

---

## Q1. Mick Carter is the landlord of a public house located at what address?

**Answer: 46 Albert Square, Walford, London E20 (a fictional address).**

- `sources/q1/d2.md` (Mick Carter): Michael "Mick" Carter is a fictional character from the BBC soap opera *EastEnders* (played by Danny Dyer) who "immediately becomes the new landlord of The Queen Victoria public house (referred to as 'The Vic')."
- `sources/q1/d3.md` (The Queen Victoria): The Queen Victoria is the Victorian public house in *EastEnders* and "has the fictional address of 46 Albert Square, Walford, London E20."

**Notes on evidence:**
- The address is explicitly **fictional** (it belongs to the fictional town of Walford in *EastEnders*); no source provides a real-world address for the pub.
- Distractor: `sources/q1/d0.md` (Fat Cat Brewery) mentions a real landlord, Colin Keatley, of the "Fat Cat" public house in Norwich — but that is not Mick Carter.
- `sources/q1/d6.md` (Linda Carter) corroborates the Carter family's association with The Queen Victoria (Linda became its landlady).

---

## Q2. "Heropanti" star Kriti Sanon appears in the remix video for a song from what Bollywood film?

**Answer: *Agent Vinod* (2012).**

- `sources/q2/d3.md` (Raabta, song): "Raabta" is a romantic Hindi song from the 2012 Bollywood film *Agent Vinod*. "The remix video of the song stars Deepika Padukone, Sushant Singh Rajput, Kriti Sanon and Jim Sarbh from the film Raabta."
- `sources/q2/d8.md` (Kriti Sanon) and `sources/q2/d6.md` (Heropanti) confirm that Kriti Sanon is a star of the 2014 Bollywood film *Heropanti* (her Hindi film debut, directed by Sabbir Khan, per `sources/q2/d1.md`).

**Notes on evidence:**
- No conflicting evidence. A subtle trap: the remix video features the cast of the film *Raabta* (2017, per `sources/q2/d2.md`), but the **song itself** is from *Agent Vinod* — the question asks for the film the song is from, so the answer is *Agent Vinod*.
- `sources/q2/d9.md` (Main Tera Boyfriend) shows Sanon in another *Raabta* film song video, but that source does not mention a remix video, so it does not bear on the question.

---

## Q3. Which restaurant was founded first, Papa Murphy's or Gino's Pizza and Spaghetti?

**Answer: Gino's Pizza and Spaghetti (founded 1961).**

- `sources/q3/d3.md` (Gino's Pizza and Spaghetti): "The company was founded by Kenney Grant in 1961."
- `sources/q3/d7.md` (Papa Murphy's): "It began in 1995 as the merger of two take-and-bake pizza companies: Papa Aldo's Pizza (founded in 1981) and Murphy's Pizza (founded in 1981)."

**Notes on evidence:**
- No conflicting evidence. Gino's Pizza and Spaghetti (1961) predates Papa Murphy's (1995) — and even predates Papa Murphy's predecessor companies (1981).
- Distractors: `sources/q3/d0.md` is about **Gino's Hamburgers** (founded 1957, Baltimore) — a different chain, not Gino's Pizza and Spaghetti. `sources/q3/d5.md` (Papa Gino's) and `sources/q3/d6.md` (Gino's East) are also unrelated chains.

---

## Q4. Who was most well-known as a radio personality and disc jockey, John Garabedian or Charles A. Agemian?

**Answer: John Garabedian.**

- `sources/q4/d9.md` (John Garabedian): "John H. Garabedian is an American radio personality and disc jockey… He is best known as the creator and former long-time host of 'Open House Party'."
- `sources/q4/d8.md` (Open House Party): The show "started in 1987, and was hosted by John Garabedian from September 1987 to January 2017. Garabedian created the show."
- `sources/q4/d3.md` (XY TV): "It was wholly owned by American radio personality John Garabedian."
- `sources/q4/d7.md` (Charles A. Agemian): Agemian "was an American banker who took early retirement from Chase Manhattan Bank… to become chairman and chief executive officer of the Hackensack Trust Co." — no radio or DJ activity is mentioned.

**Notes on evidence:**
- The evidence is one-sided: multiple sources describe Garabedian as a radio personality/DJ, while the only source on Agemian describes him solely as a banker. No source attributes any radio work to Agemian.

---

## Q5. What football team did Mario Gomez and Javi Martinez both play for?

**Answer: FC Bayern Munich.**

- `sources/q5/d8.md` (Mario Gómez): "Gómez joined Fiorentina after spending four seasons with Bayern Munich, which he joined after six years playing for VfB Stuttgart."
- `sources/q5/d7.md` (Javi Martínez): "…a Spanish footballer who plays for German club FC Bayern Munich as a defensive midfielder or a central defender."
- `sources/q5/d5.md` (2012–13 FC Bayern Munich season): "Bayern also added holding midfielder Javi Martínez after the first week of the Bundesliga season at the transfer deadline."

**Notes on evidence:**
- No conflicting evidence. Both players' sources independently place them at FC Bayern Munich, and the season source corroborates Martínez's arrival there.
- Distractors: `sources/q5/d2.md` (Kentucky Xtreme) mentions a co-owner named Mario Urrutia, and `sources/q5/d6.md` (2012 FIU Panthers) mentions coach Mario Cristobal — neither is the footballer Mario Gómez.

---

## Q6. Were Goo Goo Dolls and Echosmith formed in the same city?

**Answer: No.**

- `sources/q6/d5.md` (Goo Goo Dolls): "The Goo Goo Dolls are an American rock band formed in 1985 in **Buffalo, New York**…"
- `sources/q6/d0.md` (Echosmith): "Echosmith is an American… indie pop band formed in February 2009 in **Chino, California**."

**Notes on evidence:**
- No conflicting evidence. Buffalo, New York and Chino, California are different cities, so the bands were not formed in the same city.
- Other Goo Goo Dolls sources (`sources/q6/d1.md`, `d2.md`, `d3.md`, `d4.md`, `d6.md`, `d7.md`, `d8.md`, `d9.md`) concern albums and songs and do not contradict the formation city.

---

## Summary Table

| # | Question (short) | Answer | Key sources |
|---|---|---|---|
| 1 | Mick Carter's pub address | 46 Albert Square, Walford, London E20 (fictional) | q1/d2.md, q1/d3.md |
| 2 | Film of the song whose remix video features Kriti Sanon | *Agent Vinod* (2012) | q2/d3.md, q2/d8.md |
| 3 | Founded first: Papa Murphy's or Gino's Pizza and Spaghetti? | Gino's Pizza and Spaghetti (1961 vs. 1995) | q3/d3.md, q3/d7.md |
| 4 | More well-known radio personality/DJ | John Garabedian | q4/d9.md, q4/d8.md, q4/d7.md |
| 5 | Team shared by Mario Gómez and Javi Martínez | FC Bayern Munich | q5/d8.md, q5/d7.md, q5/d5.md |
| 6 | Same formation city? | No (Buffalo, NY vs. Chino, CA) | q6/d5.md, q6/d0.md |

**Overall assessment:** All six questions are answerable from the supplied sources with no unresolved conflicts. The main caveats are (a) the Q1 address is explicitly fictional, and (b) several distractor sources in each collection (e.g., Gino's Hamburgers, Gino's East, Papa Gino's, the real-world "Fat Cat" landlord, Mario Urrutia/Cristobal) refer to similarly named but distinct entities and were excluded from the answers.
