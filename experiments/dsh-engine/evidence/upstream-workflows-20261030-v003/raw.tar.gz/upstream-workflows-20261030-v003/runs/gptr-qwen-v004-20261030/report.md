

# 多智能体深度研究系统的编排机制比较：Open Deep Research、GPT Researcher 与 DeepSeek Harness

## 摘要

本报告基于对三个开源多智能体研究系统的源码级分析，系统比较了 Open Deep Research（LangChain）、GPT Researcher 和 DeepSeek Harness 在请求分解、子执行创建、并发控制、结果汇合及迭代依赖方面的实际编排机制。研究发现，三个系统在"动态性"程度上存在显著差异：Open Deep Research 实现了真正的动态监督者循环，GPT Researcher 采用静态单遍扇出，而 DeepSeek Harness 则提供了通用的层级激活基础设施。基于证据标准分析，只有 Open Deep Research 满足"动态 Agent DAG"的充分条件。

## 1. 引言

多智能体深度研究系统的核心挑战在于：如何将一个高层研究请求分解为可独立执行的子任务，在资源约束下并行执行这些子任务，并将结果有效汇合以驱动后续决策。三个被比较的系统代表了三种不同的设计哲学——LLM 驱动的动态编排、预定义的静态扇出、以及通用基础设施层的激活管理。

## 2. 请求到独立研究工作的转化机制

### 2.1 Open Deep Research：LLM 动态分解

Open Deep Research 的核心机制是一个由 LLM 监督者驱动的动态循环。在每次迭代中，监督者模型根据当前研究状态自主决定生成多少个 `ConductResearch` 工具调用以及每个调用的具体研究主题。这一过程并非预定义的扇出，而是模型在运行时通过工具调用生成动态确定的 ([LangChain, 2024](https://github.com/langchain-ai/open_deep_research/blob/1b7d2e80db9faa586165c60e09096dbbfd483a64/src/open_deep_research/deep_researcher.py))。

具体而言，代码从监督者最近一条消息中提取所有 `ConductResearch` 工具调用，然后对允许范围内的调用并行执行 `researcher_subgraph.ainvoke()`，每个调用携带独立的 `research_topic` 参数 ([LangChain, 2024](https://github.com/langchain-ai/open_deep_research/blob/1b7d2e80db9faa586165c60e09096dbbfd483a64/src/open_deep_research/deep_researcher.py))。

### 2.2 GPT Researcher：预定义广度查询

GPT Researcher 采用完全不同的策略。其 `deep_research` 技能首先通过单次 LLM 调用生成 N 个广度查询（`generate_search_queries(query, num_queries=breadth)`），然后为每个查询创建一个独立的 `GPTResearcher` 实例 ([GPT Researcher, 2024](https://github.com/assafelovic/gpt-researcher/blob/3582a6841fe7dc801e2a34e34ee408641aea9bce/gpt_researcher/skills/deep_research.py))。

关键区别在于：查询的生成是一次性的，后续不存在基于先前结果的再分解。每个子研究者是独立的、一次性的实例，不接收来自其他子研究者的输出 ([GPT Researcher, 2024](https://github.com/assafelovic/gpt-researcher/blob/3582a6841fe7dc801e2a34e34ee408641aea9bce/gpt_researcher/skills/deep_research.py))。

### 2.3 DeepSeek Harness：通用激活委派

DeepSeek Harness 不直接实现研究逻辑，而是提供通用的子代理委派基础设施。其 `startActivation` 接口接受 `provider`、`label`、`request` 等参数，将工作路由到具名提供方后端 ([DeepSeek AI, 2024](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/subagent/subagent/README.md))。请求到独立工作的转化完全由上层编排逻辑决定，Harness 本身不施加研究语义。

## 3. 子执行创建的层级

| 维度 | Open Deep Research | GPT Researcher | DeepSeek Harness |
|------|-------------------|----------------|-----------------|
| 创建者 | 监督者 LLM（通过工具调用） | 父级 `deep_research` 技能 | 任意持有委派工具的代理 |
| 创建时机 | 每次监督者迭代 | 单次预生成后 | 按需（工具调用触发） |
| 子执行类型 | `researcher_subgraph`（LangGraph 子图） | 独立 `GPTResearcher` 实例 | 本地 spawn/fork 或外部后端 |
| 层级深度 | 固定两层（监督者→研究者） | 隐式（无显式深度控制） | `maxDepth` 控制（默认 1） |
| 持久性 | 无（一次性子图调用） | 无（一次性实例） | 本地子代理支持持久会话和冷恢复 |

Open Deep Research 的子执行通过 `researcher_subgraph.ainvoke()` 创建，每次调用都是独立的 LangGraph 子图实例，执行完毕后即销毁 ([LangChain, 2024](https://github.com/langchain-ai/open_deep_research/blob/1b7d2e80db9faa586165c60e09096dbbfd483a64/src/open_deep_research/deep_researcher.py))。

GPT Researcher 的子执行通过 `GPTResearcher(query=serp_query['query'], ...)` 构造函数创建，每个实例独立执行 `conduct_research()` 方法 ([GPT Researcher, 2024](https://github.com/assafelovic/gpt-researcher/blob/3582a6841fe7dc801e2a34e34ee408641aea9bce/gpt_researcher/skills/deep_research.py))。

DeepSeek Harness 的子执行通过 `startActivation` 创建，返回 `{ childId, messageId?, result, dispose }` 结构。本地子代理保留持久会话以接受后续消息，而外部后端（ACP、DSH SDK、Codex、Claude Code）仅执行一次 ([DeepSeek AI, 2024](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/subagent/subagent/README.md))。

## 4. 并行工作的边界与汇合

### 4.1 三种并发控制策略

三个系统代表了三种截然不同的并发控制范式：

**（1）列表截断与错误反馈（Open Deep Research）**

代码直接对工具调用列表进行切片：`allowed_conduct_research_calls = conduct_research_calls[:configurable.max_concurrent_research_units]`，超出部分收到包含具体限制数值的错误消息，要求 LLM 在下一迭代中重新规划 ([LangChain, 2024](https://github.com/langchain-ai/open_deep_research/blob/1b7d2e80db9faa586165c60e09096dbbfd483a64/src/open_deep_research/deep_researcher.py))。这是一种**软背压机制**——不终止流程，而是将约束信息反馈给决策者。

**（2）信号量等待（GPT Researcher）**

使用 `asyncio.Semaphore(self.concurrency_limit)` 限制并发，超出限制的协程在信号量处排队等待 ([GPT Researcher, 2024](https://github.com/assafelovic/gpt-researcher/blob/3582a6841fe7dc801e2a34e34ee408641aea9bce/gpt_researcher/skills/deep_research.py))。这是一种**阻塞式排队**——所有任务最终都会执行，只是顺序被延迟。

**（3）槽位预留与立即拒绝（DeepSeek Harness）**

新建和冷恢复激活在让出执行前预留槽位，容量耗尽时以 `ACTIVATION_LIMIT_REACHED` 立即拒绝，不排队 ([DeepSeek AI, 2024](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/subagent/subagent/README.md))。文档明确解释了设计动机："接纳不会排队，避免等待后代的父代理又等待自己占用的名额"——即防止父代理因等待子代理而自身占用槽位导致的死锁。

### 4.2 汇合机制

| 系统 | 汇合方式 | 汇合点 | 信息保真度 |
|------|---------|--------|-----------|
| Open Deep Research | `asyncio.gather` 等待所有子图完成 | 监督者上下文（通过 ToolMessage） | 压缩（`compressed_research`） |
| GPT Researcher | `asyncio.gather` 等待所有信号量任务完成 | 父级 `deep_research` 技能 | 完整（learnings、citations、context） |
| DeepSeek Harness | `delivery: 'parent'` 或 `delivery: 'caller'` | 父代理消息队列或调用方 | 取决于后端实现 |

Open Deep Research 的汇合涉及一个关键的**信息压缩步骤**：子研究者返回的 `compressed_research` 字段是合成/摘要后的输出，而非原始研究笔记 ([LangChain, 2024](https://github.com/langchain-ai/open_deep_research/blob/1b7d2e80db9faa586165c60e09096dbbfd483a64/src/open_deep_research/deep_researcher.py))。如果合成失败超过最大重试次数，则回退到错误字符串 `"Error synthesizing research report: Maximum retries exceeded"`。这一设计明确管理了监督者上下文窗口的约束。

## 5. 后续工作对先前发现的依赖

这是区分"动态 DAG"与"静态扇出"的核心维度。

**Open Deep Research** 实现了真正的迭代依赖。`max_researcher_iterations`（默认 6，范围 1-10）定义了监督者反思循环的上限——"Research Supervisor 将反思研究并提出后续问题的次数" ([LangChain, 2024](https://github.com/langchain-ai/open_deep_research/blob/1b7d2e80db9faa586165c60e09096dbbfd483a64/src/open_deep_research/configuration.py))。每次迭代中，监督者基于前一次迭代收到的 `compressed_research` 结果决定是否需要进一步研究、研究什么方向。这构成了一个**有界迭代深化模式**，而非单次分解。

**GPT Researcher** 不存在迭代依赖。所有子研究者在同一层并行执行，其结果在汇合后直接用于最终报告生成。系统有一个"停止下降"机制——当零查询被生成时停止递归——但这是被动终止条件而非主动深度控制 ([GPT Researcher, 2024](https://github.com/assafelovic/gpt-researcher/blob/3582a6841fe7dc801e2a34e34ee408641aea9bce/gpt_researcher/skills/deep_research.py))。`visited_urls` 的传播仅防止冗余 URL 获取，不解决上下文丢失或质量退化问题。

**DeepSeek Harness** 本身不实现研究依赖逻辑，但其持久会话机制（本地子代理接受后续消息）为上层编排提供了实现迭代依赖的基础设施能力。`delivery: 'parent'` 模式允许父代理在子代理完成后收到通知并决定后续动作 ([DeepSeek AI, 2024](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/subagent/subagent/README.md))。

## 6. 动态 Agent DAG 的证据标准

要判定一个系统的执行图是否为"动态 Agent DAG"，需要满足以下证据条件：

| 证据条件 | Open Deep Research | GPT Researcher | DeepSeek Harness |
|---------|-------------------|----------------|-----------------|
| 子任务数量由运行时决策确定 | ✅ LLM 工具调用生成 | ❌ 预生成固定数量 | ⚠️ 取决于上层 |
| 子任务内容基于先前结果 | ✅ 监督者反思循环 | ❌ 无迭代 | ⚠️ 取决于上层 |
| 执行图拓扑非预定义 | ✅ 每迭代可能不同 | ❌ 固定星型拓扑 | ⚠️ 取决于上层 |
| 存在条件分支（基于结果的路由） | ✅ 溢出反馈触发重规划 | ❌ 无 | ⚠️ 取决于上层 |
| 有界终止保证 | ✅ `max_researcher_iterations` | ⚠️ 被动（零查询停止） | ✅ `maxDepth` + `maxActiveSubagents` |

**我的判断**：基于上述证据标准，Open Deep Research 是唯一满足"动态 Agent DAG"充分条件的系统。其执行图的拓扑结构（节点数量和边）在每次运行时由 LLM 决策动态确定，且后续节点的存在和内容直接依赖于先前节点的输出。GPT Researcher 的执行图在查询生成完成后即完全确定，本质上是静态的星型 DAG。DeepSeek Harness 作为基础设施层，本身不产生动态性——它提供的是使动态性成为可能的约束框架。

## 7. 设计权衡分析

三个系统的并发控制策略反映了不同的设计假设：

- **Open Deep Research 的列表截断**假设 LLM 能够理解错误反馈并调整行为。这是一种"信任模型能力"的策略，优势在于不阻塞任何任务，劣势在于依赖 LLM 的指令遵循能力。
- **GPT Researcher 的信号量**假设所有任务都值得执行，只是需要限流。这是一种"保守但完整"的策略，优势在于保证所有工作完成，劣势在于可能引入不必要的延迟。
- **DeepSeek Harness 的立即拒绝**假设系统必须避免死锁，宁可拒绝也不排队。这是一种"安全优先"的策略，优势在于确定性终止，劣势在于可能浪费已生成的工作请求。

值得注意的是，DeepSeek Harness 的文档明确将"不排队"与死锁预防关联：等待后代的父代理如果也占用槽位，将导致池饥饿 ([DeepSeek AI, 2024](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/subagent/subagent/README.md))。这一设计决策在 Open Deep Research 和 GPT Researcher 中不存在对应问题，因为它们的父级（监督者/父技能）不占用并发槽位。

## 8. 结论

三个系统代表了多智能体编排光谱上的不同位置。Open Deep Research 实现了最接近"动态 Agent DAG"的机制，其 LLM 监督者循环提供了真正的运行时拓扑决策能力。GPT Researcher 是一个高效的静态扇出系统，适合广度优先的研究场景但缺乏深度迭代能力。DeepSeek Harness 提供了最完善的并发安全基础设施，其预留-执行模式和死锁预防设计为构建更复杂的动态编排系统奠定了可靠基础。

从工程实践角度，一个理想的深度研究系统可能结合三者的优势：使用 DeepSeek Harness 式的槽位管理确保并发安全，采用 Open