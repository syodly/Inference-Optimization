

# Orchestration Mechanisms: Open Deep Research vs. GPT Researcher vs. DeepSeek Harness

## Overview

This report provides a detailed technical comparison of the orchestration mechanisms in three multi-agent research systems: **Open Deep Research** (`langchain-ai/open_deep_research`), **GPT Researcher** (`assafelovic/gpt-researcher`), and **DeepSeek Harness** (`deepseek-ai/deepseek-harness`). Each system addresses the same fundamental problem — decomposing a user's research request into parallelizable work units, executing them concurrently, and synthesizing results — but employs distinct architectural patterns for decomposition, child creation, parallelism control, joining, and dependency resolution.

The level of source-level detail available varies across the three systems. Open Deep Research has confirmed code-level evidence from its primary orchestration file. GPT Researcher has partial code evidence from a skill module, with the core orchestration layer not fully retrieved. DeepSeek Harness has detailed documentation from its subagent package README but no implementation source code was retrieved. Gaps are explicitly marked throughout.

---

## System 1: Open Deep Research

### Repository and Entry Point

**[FACT]** The repository is [langchain-ai/open_deep_research](https://github.com/langchain-ai/open_deep_research) [1]. The primary orchestration logic resides in `src/open_deep_research/deep_researcher.py` [1], with configuration defined in `src/open_deep_research/configuration.py` [2].

**[NOT DETERMINED]** The exact entry point (CLI command, API endpoint, or `__main__.py`) was not identified from available sources. The system is built on LangGraph, with the orchestration layer exposed as a `CompiledGraph` (inferred from the `.ainvoke()` invocation pattern).

### Request-to-Task Decomposition

**[FACT]** Decomposition is entirely **LLM-driven via tool calling**. There is no dedicated `decompose()`, `plan()`, or `dispatch()` function. The architecture designates an LLM as a "Research Supervisor" that decides how to break down the user's request by emitting one or more `ConductResearch` tool calls. Each tool call carries a `research_topic` argument that defines the scope of a single research work unit.

The mechanism is captured in `deep_researcher.py` (lines 282–286) [1]:

```python
# Handle ConductResearch calls (research delegation)
conduct_research_calls = [
    tool_call for tool_call in most_recent_message.tool_calls 
    if tool_call["name"] == "ConductResearch"
]
```

The supervisor inspects the LLM's `tool_calls` output and filters for calls named `"ConductResearch"`. The number of such calls (0, 1, N) is determined entirely by the LLM at runtime based on its reasoning about the current task state.

**[FACT]** The decomposition is **iterative**. The supervisor can issue multiple rounds of `ConductResearch` calls across successive iterations, bounded by `max_researcher_iterations` (default 6, maximum 10) [2]. This means the supervisor reflects on accumulated results and may spawn additional research units in subsequent rounds.

**[NOT DETERMINED]** The exact system prompt that instructs the LLM how to decompose the request, and the JSON schema definition for the `ConductResearch` tool (including parameter descriptions visible to the model), were not captured from available sources.

### Child Execution Creation

**[FACT]** Child executions are spawned by calling `researcher_subgraph.ainvoke()` for each allowed `ConductResearch` tool call. This occurs in `deep_researcher.py` (lines 294–303) [1]:

```python
# Execute research tasks in parallel
research_tasks = [
    researcher_subgraph.ainvoke({
        "researcher_messages": [
            HumanMessage(content=tool_call["args"]["research_topic"])
        ],
        "research_topic": tool_call["args"]["research_topic"]
    }, config) 
    for tool_call in allowed_conduct_research_calls
]
```

The child is a **LangGraph subgraph invocation**. The input state is a dictionary with two keys:
- `"researcher_messages"`: A list containing a single `HumanMessage` whose content is the `research_topic`
- `"research_topic"`: The research topic string (passed separately for state tracking)

The `researcher_subgraph` is a LangGraph `CompiledGraph` that internally runs its own agent loop (a ReAct pattern with tool calling, bounded by `max_react_tool_calls`, default 10, maximum 30) [2].

**[NOT DETERMINED]** The exact construction of `researcher_subgraph` — which nodes, edges, and tools it contains — was not fully retrieved. Critically, it remains unconfirmed whether `researcher_subgraph` itself contains a `ConductResearch` tool that would enable recursive spawning (i.e., children spawning grandchildren).

### Parallelism Bounding

**[FACT]** Parallelism is bounded by **simple list slicing**, not by a semaphore, queue, or token-bucket mechanism. The configuration value `max_concurrent_research_units` (default 5, range 1–20) controls the limit [2].

From `deep_researcher.py` (lines 290–292) [1]:

```python
# Limit concurrent research units to prevent resource exhaustion
allowed_conduct_research_calls = conduct_research_calls[:configurable.max_concurrent_research_units]
overflow_conduct_research_calls = conduct_research_calls[configurable.max_concurrent_research_units:]
```

**[FACT]** Overflow calls (those beyond the limit) are **not queued or retried**. They receive an error `ToolMessage` that informs the supervisor of the limit and asks it to re-plan with fewer units [1]:

```python
for overflow_call in overflow_conduct_research_calls:
    all_tool_messages.append(ToolMessage(
        content=f"Error: Did not run this research as you have already exceeded the maximum number of concurrent research units. Please try again with {configurable.max_concurrent_research_units} or fewer research units.",
        name="ConductResearch",
        tool_call_id=overflow_call["id"]
    ))
```

This creates a **soft bound**: the LLM is informed of the constraint and expected to adapt its next iteration accordingly.

### Joining Mechanism

**[FACT]** Parallel branches are joined via **`asyncio.gather`** (line 305) [1]:

```python
tool_results = await asyncio.gather(*research_tasks)
```

After gathering, results are processed into two streams:

1. **Per-child `ToolMessage`**: Each child's `compressed_research` field becomes a `ToolMessage` fed back to the supervisor LLM (lines 307–313) [1]:
   ```python
   for observation, tool_call in zip(tool_results, allowed_conduct_research_calls):
       all_tool_messages.append(ToolMessage(
           content=observation.get("compressed_research", "Error synthesizing research report: Maximum retries exceeded"),
           name=tool_call["name"],
           tool_call_id=tool_call["id"]
       ))
   ```

2. **Concatenated `raw_notes`**: All children's `raw_notes` are joined into a single string (lines 323–325, truncated in available source) [1]:
   ```python
   raw_notes_concat = "\n".join([
       "\n".join(observation.get("
   ```
   This concatenated raw notes string is presumably used for the final report synthesis.

**[FACT]** The joining is thus a **two-level aggregation**: a compressed summary per child goes to the supervisor for re-planning, while the full raw notes are preserved for the final output.

### Dependency Resolution Between Steps

**[FACT]** Dependencies are resolved through a **sequential supervisor loop with accumulated context**, not an explicit dependency graph. The mechanism operates as follows:

1. After each round of parallel research completes, the `ToolMessage` objects (containing `compressed_research` from all children) are appended to the supervisor's message history.
2. The supervisor LLM re-invokes, seeing all prior results in its context window.
3. The supervisor may issue new `ConductResearch` calls with topics informed by prior findings (e.g., "The previous research found X; now investigate Y in more detail").
4. This loop repeats up to `max_researcher_iterations` times [2].

Intermediate results propagate via two channels:
- **Message passing**: The `researcher_messages` list in the LangGraph state accumulates, so the supervisor's context grows with each iteration.
- **Raw notes accumulation**: The `raw_notes_concat` string grows across iterations, preserving full detail for final synthesis.

There is no explicit DAG data structure, no dependency graph, and no topological sort. The dependency is implicit in the LLM's context window.

### DAG Classification Verdict

| Condition | Met? | Evidence |
|-----------|------|----------|
| Runtime-conditional branching | **YES** | Number of `ConductResearch` calls determined by LLM at runtime; code checks `if conduct_research_calls:` — 0, 1, or N possible [1] |
| Data-dependent task creation | **YES** | Supervisor sees prior `compressed_research` in message history and generates new topics informed by them [1] |
| Non-uniform depth | **PARTIAL** | Each child runs its own ReAct loop (bounded by `max_react_tool_calls`). Whether children can spawn sub-children is unconfirmed [2] |
| Loops that re-plan | **YES** | Supervisor loop iterates up to `max_researcher_iterations` times with reflection [2] |
| Non-uniform fan-out | **YES** | LLM decides how many calls to emit per iteration; not fixed [1] |
| Static pipeline | **NO** | Number of iterations and children per iteration is LLM-determined [1] |
| Fixed tree | **NO** | Structure emerges from LLM decisions, not pre-defined [1] |
| Flat parallel fan-out | **PARTIAL** | If children cannot spawn sub-children, it's a 2-level structure. But multi-iteration makes it a **multi-round fan-out with feedback** |

**[FACT]** **Verdict:** The architecture is best classified as a **dynamic, multi-round fan-out with feedback** — a bounded-depth dynamic DAG with maximum depth of 2 (supervisor → workers), where the supervisor can issue new fan-outs across up to 6 rounds based on accumulated context. It is **not** a fully recursive dynamic DAG unless `researcher_subgraph` itself contains the `ConductResearch` tool (which would enable recursive spawning). This possibility cannot be confirmed from available code.

---

## System 2: GPT Researcher

### Repository and Entry Point

**[FACT]** The repository is [assafelovic/gpt-researcher](https://github.com/assafelovic/gpt-researcher) [3]. The confirmed code excerpt is from `gpt_researcher/skills/deep_research.py` [3], which represents the "deep research" skill (a higher-level orchestration mode) rather than the core single-query research pipeline.

**[NOT DETERMINED]** The core orchestration files (`core/task.py`, `core/gpt_researcher.py`, `core/reports/agent.py`, `core/promptstrategies.py`, `core/config.py`) were not retrieved from available sources. The classic GPT Researcher architecture (with a `Task` class, `decompose_subtasks()`, and `execute()` methods) is known from training data but **cannot be cited with specific line numbers or file paths** from the research conducted here.

### Request-to-Task Decomposition

**[FACT]** In the deep research skill (`gpt_researcher/skills/deep_research.py`), decomposition is performed by a method called `self.generate_search_queries(query, num_queries=breadth)` (line 418) [3]:

```python
serp_queries = await self.generate_search_queries(query, num_queries=breadth)
print(f"✅ Generated {len(serp_queries)} queries: {[q['query'] for q in serp_queries]}", flush=True)
```

This method takes the original query and a breadth parameter, and produces a list of `serp_queries` (dictionaries with at least a `'query'` key). Based on the naming and pattern, this is an **LLM-based query generation step** — the LLM decomposes the research question into multiple search queries. The `num_queries=breadth` parameter controls how many sub-queries to generate.

**[FACT]** If zero queries are generated, the system gracefully degrades, returning accumulated learnings from prior steps (lines 421–429) [3]:

```python
if not serp_queries:
    logger.warning("Deep research generated zero search queries; stopping descent.")
    return {
        'learnings': all_learnings,
        'visited_urls': all_visited_urls,
        'citations': all_citations,
        'context': all_context,
        'sources': all_sources,
    }
```

**[NOT DETERMINED]** The implementation of `generate_search_queries` (the exact prompt, the LLM model used, the output format) was not retrieved. In the classic GPT Researcher core (not the deep research skill), decomposition is handled by a `Task` class with a `decompose_subtasks()` method that uses an LLM to split a query into sub-queries — but this could not be confirmed with source citations in this research.

### Child Execution Creation

**[FACT]** In the deep research skill, child executions are created by **instantiating new `GPTResearcher` objects** within an inner async function (lines 441–454) [3]:

```python
from .. import GPTResearcher
researcher = GPTResearcher(
    query=serp_query['query'],
    report_type=ReportType.ResearchReport.value,
    report_source=ReportSource.Web.value,
    tone=self.tone,
    websocket=self.websocket,
    config_path=self.config_path,
    headers=self.headers,
    visited_urls=self.visited_urls,
    # Propagate MCP configuration to nested researchers
    mcp_configs=self.researcher.mcp_configs,
    mcp_strategy=self.researcher.mcp_strategy
)
```

Each child is a **full `GPTResearcher` instance** — not a subgraph, not a lightweight coroutine. It is a complete research agent that will conduct its own research cycle (search, scrape, process, synthesize).

**[FACT]** The child's execution is triggered by calling `researcher.conduct_research()` (line 457) [3]. This method runs the full research pipeline for that sub-query.

**[FACT]** Notably, the `visited_urls` set is **shared across nested researchers** (passed at line 450) [3], providing a deduplication mechanism — if two sub-queries lead to the same URL, it won't be scraped twice.

**[FACT]** MCP (Model Context Protocol) configuration is propagated to nested researchers (lines 452–453) [3], indicating that tool/function-calling capabilities are inherited by children.

### Parallelism Bounding

**[FACT]** In the deep research skill, parallelism is bounded by an **`asyncio.Semaphore`** (line 432) [3]:

```python
# Process queries with concurrency limit
semaphore = asyncio.Semaphore(self.concurrency_limit)
```

Each child execution is wrapped in `async with semaphore:` (line 435) [3]:

```python
async def process_query(serp_query: Dict[str, str]) -> Optional[Dict[str, Any]]:
    async with semaphore:
        try:
            ...
```

**[NOT DETERMINED]** The default value of `self.concurrency_limit` was not captured. In the classic GPT Researcher, this is typically configured via the config file (often defaulting to 4 or 10), but the specific value in the deep research skill's context could not be confirmed.

**[FACT]** This is a fundamentally different mechanism from Open Deep Research's list slicing. A semaphore provides **true backpressure** — all tasks are created as coroutines, but only `concurrency_limit` execute simultaneously. Others wait for a slot to become available. In contrast, Open Deep Research simply discards overflow tasks with an error message.

### Joining Mechanism

**[FACT]** Based on the code structure (the `process_query` function returns `Optional[Dict[str, Any]]`), the joining mechanism in the deep research skill likely uses `asyncio.gather` over all `process_query` coroutines (though the exact gather call was not captured in the retrieved excerpt). Results are then processed via `self.process_research_results(query=serp_query['query'], ...)` (line 464) [3] to extract learnings and citations.

**[FACT]** The returned data structure from each child includes:
- `visited` URLs (from `researcher.visited_urls`, line 460)
- `sources` (from `researcher.research_sources`, line 461)
- Processed results (learnings, citations) via `process_research_results` (line 464)

**[NOT DETERMINED]** The final synthesis mechanism (how all sub-query results are combined into a single report) was not captured from available sources.

### Dependency Resolution Between Steps

**[FACT]** In the deep research skill, the dependency mechanism is **sequential with shared state**:

1. The `visited_urls` set is shared across all nested researchers, providing implicit deduplication.
2. The `all_learnings`, `all_visited_urls`, `all_citations`, `all_context`, and `all_sources` variables (visible in the early-return