"""Run pinned GPT Researcher deep research against local Qwen and a fixed corpus."""
import asyncio
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import json
import os
from pathlib import Path
import shutil
import threading
import time
import traceback
from urllib.parse import parse_qs, urlparse

ROOT = Path('/home/Liangyijia_Hu/dsh-lab')
RUN_ID = 'gptr-qwen-v005-20261030'
OUT = ROOT / 'upstream-runs' / RUN_ID
CORPUS = [
    {
        'url': 'https://github.com/langchain-ai/open_deep_research/blob/1b7d2e80db9faa586165c60e09096dbbfd483a64/src/open_deep_research/deep_researcher.py',
        'raw_content': (ROOT / 'upstream/open_deep_research/open_deep_research/deep_researcher.py').read_text(),
    },
    {
        'url': 'https://github.com/langchain-ai/open_deep_research/blob/1b7d2e80db9faa586165c60e09096dbbfd483a64/src/open_deep_research/configuration.py',
        'raw_content': (ROOT / 'upstream/open_deep_research/open_deep_research/configuration.py').read_text(),
    },
    {
        'url': 'https://github.com/assafelovic/gpt-researcher/blob/3582a6841fe7dc801e2a34e34ee408641aea9bce/gpt_researcher/skills/deep_research.py',
        'raw_content': (ROOT / 'upstream/gptr-pinned/gpt_researcher__skills__deep_research.py').read_text(),
    },
    {
        'url': 'https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/subagent/subagent/README.zh.md',
        'raw_content': (ROOT / 'runtime/node_modules/@deepseek-ai/dsh-subagent/README.zh.md').read_text(),
    },
]
QUERY = (
    'Compare the actual orchestration mechanisms in Open Deep Research, GPT Researcher, and DeepSeek Harness. '
    'Explain how a request becomes independent research work, which layer creates each child execution, how '
    'parallel work is bounded and joined, how later work depends on earlier findings, and what evidence is '
    'needed to call the result a dynamic agent DAG. Cite the supplied source paths and keep framework facts '
    'separate from design proposals.'
)

# Exact source excerpts, not model-written summaries. Full source is retained
# separately. Returning every complete file on every query overflowed the
# official final-report context in v003.
SOURCE_RANGES = [[(288, 305)], [(64, 75), (94, 118)], [(418, 432), (493, 554)], [(45, 55)]]
for row, ranges in zip(CORPUS, SOURCE_RANGES):
    full = row['raw_content']
    row['full_source_sha256'] = hashlib.sha256(full.encode()).hexdigest()
    lines = full.splitlines()
    excerpt = '\n'.join('\n'.join(f'{i+1}: {lines[i]}' for i in range(first-1, min(last, len(lines)))) for first,last in ranges)
    row['raw_content'] = f"SOURCE: {row['url']}\nExact source line excerpts:\n" + excerpt

EVENTS = []
ACTIVE = 0
PEAK_ACTIVE = 0
LOCK = threading.Lock()
RETRIEVALS = []


def event(kind, **fields):
    row = {'event': kind, 'wall_time': time.time(), **fields}
    EVENTS.append(row)
    with (OUT / 'events.jsonl').open('a', encoding='utf8') as stream:
        stream.write(json.dumps(row, ensure_ascii=False, default=str) + '\n')


class RetrieverHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        query = parse_qs(urlparse(self.path).query).get('query', [''])[0]
        tokens = {token.lower().strip('.,:;()[]{}"\'') for token in query.split() if len(token) > 3}
        scored = []
        for row in CORPUS:
            body = row['raw_content']
            score = sum(body.lower().count(token) for token in tokens)
            scored.append((score, row))
        result = [row for _, row in sorted(scored, key=lambda x: x[0], reverse=True)]
        RETRIEVALS.append({'wall_time': time.time(), 'query': query, 'returned': [x['url'] for x in result]})
        payload = json.dumps(result, ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header('content-type', 'application/json; charset=utf-8')
        self.send_header('content-length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *_):
        pass


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    (OUT / 'corpus').mkdir()
    for index, row in enumerate(CORPUS, start=1):
        (OUT / 'corpus' / f'{index:02d}.json').write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding='utf8')
    corpus_hash = hashlib.sha256(json.dumps(CORPUS, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    server = ThreadingHTTPServer(('127.0.0.1', 0), RetrieverHandler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    os.environ.update({
        'OPENAI_API_KEY': 'local-qwen-no-auth',
        'OPENAI_BASE_URL': 'http://127.0.0.1:18083/v1',
        'FAST_LLM': 'openai:qwen27b',
        'SMART_LLM': 'openai:qwen27b',
        'STRATEGIC_LLM': 'openai:qwen27b',
        'RETRIEVER': 'custom',
        'RETRIEVER_ENDPOINT': f'http://127.0.0.1:{server.server_port}/search',
        'DEEP_RESEARCH_BREADTH': '2',
        'DEEP_RESEARCH_DEPTH': '2',
        'DEEP_RESEARCH_CONCURRENCY': '2',
        'MAX_ITERATIONS': '1',
        'LANGUAGE': 'english',
        'TOTAL_WORDS': '800',
        'REASONING_EFFORT': 'low',
        'COMPRESSION_THRESHOLD': '150000',
        'LLM_KWARGS': json.dumps({'max_tokens': 8192, 'temperature': 0}),
    })
    (OUT / 'spec.json').write_text(json.dumps({
        'run_id': RUN_ID,
        'framework': 'GPT Researcher 0.16.0',
        'source_commit': '3582a6841fe7dc801e2a34e34ee408641aea9bce',
        'query': QUERY,
        'model': 'Qwen3.8-27B via local vLLM OpenAI-compatible endpoint',
        'temperature': 0,
        'reasoning_effort': 'low (provider default; source has per-stage overrides)',
        'config': {'breadth': 2, 'depth': 2, 'concurrency': 2, 'max_iterations': 1, 'max_tokens': 8192, 'language':'english', 'total_words':800},
        'task_worker_count_prescribed': False,
        'workflow_or_query_list_prescribed': False,
        'corpus_documents': len(CORPUS),
        'corpus_sha256': corpus_hash,
        'retrieval_mode': 'four exact source excerpts including the recursive call through official custom retriever; no live web search',
        'compression_mode': 'official small-document fast path (COMPRESSION_THRESHOLD=150000); no embeddings endpoint required',
    }, ensure_ascii=False, indent=2), encoding='utf8')

    import gpt_researcher
    from gpt_researcher import GPTResearcher
    import gpt_researcher.skills.deep_research as deep_research

    original_class = GPTResearcher
    original_gather = deep_research.asyncio.gather

    def traced_constructor(*args, **kwargs):
        obj = original_class(*args, **kwargs)
        event('researcher_created', query=obj.query, parent_query=obj.parent_query,
              report_type=obj.report_type, id=obj._generate_research_id())
        original_conduct = obj.conduct_research

        async def traced_conduct(*conduct_args, **conduct_kwargs):
            global ACTIVE, PEAK_ACTIVE
            with LOCK:
                ACTIVE += 1
                PEAK_ACTIVE = max(PEAK_ACTIVE, ACTIVE)
                active = ACTIVE
            event('researcher_started', query=obj.query, active=active)
            try:
                return await original_conduct(*conduct_args, **conduct_kwargs)
            finally:
                with LOCK:
                    ACTIVE -= 1
                    active = ACTIVE
                event('researcher_finished', query=obj.query, active=active)

        obj.conduct_research = traced_conduct
        return obj

    async def traced_gather(*aws, **kwargs):
        event('gather_started', awaitable_count=len(aws))
        try:
            return await original_gather(*aws, **kwargs)
        finally:
            event('gather_finished', awaitable_count=len(aws))

    gpt_researcher.GPTResearcher = traced_constructor
    deep_research.asyncio.gather = traced_gather
    researcher = original_class(query=QUERY, report_type='deep', verbose=False, max_subtopics=3)
    start = time.time()
    completion = {'run_id': RUN_ID, 'started_wall_time': start,
                  'started_utc': datetime.fromtimestamp(start, timezone.utc).isoformat(), 'status': 'running'}
    (OUT / 'launch.json').write_text(json.dumps(completion, indent=2), encoding='utf8')
    try:
        async def execute():
            context = await researcher.conduct_research()
            report = await researcher.write_report()
            return context, report

        context, report = asyncio.run(execute())
        (OUT / 'report.md').write_text(report, encoding='utf8')
        (OUT / 'context.txt').write_text(context if isinstance(context, str) else json.dumps(context, ensure_ascii=False, indent=2), encoding='utf8')
        completion.update({'status': 'success' if report.strip() else 'empty_report', 'context_chars': len(context), 'report_chars': len(report),
                           'research_sources': len(researcher.research_sources),
                           'visited_urls': len(researcher.visited_urls)})
    except Exception as exc:
        completion.update({'status': 'error', 'error': repr(exc), 'traceback': traceback.format_exc()})
        (OUT / 'error.txt').write_text(completion['traceback'], encoding='utf8')
    finally:
        server.shutdown()
    end = time.time()
    completion.update({'finished_wall_time': end, 'finished_utc': datetime.fromtimestamp(end, timezone.utc).isoformat(),
                       'duration_seconds': end - start, 'researcher_instances': sum(e['event']=='researcher_created' for e in EVENTS),
                       'peak_active_researchers': PEAK_ACTIVE, 'retriever_calls': len(RETRIEVALS),
                       'events': EVENTS, 'retrievals': RETRIEVALS})
    (OUT / 'completion.json').write_text(json.dumps(completion, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps({k: v for k, v in completion.items() if k not in ('events', 'retrievals', 'traceback')}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
