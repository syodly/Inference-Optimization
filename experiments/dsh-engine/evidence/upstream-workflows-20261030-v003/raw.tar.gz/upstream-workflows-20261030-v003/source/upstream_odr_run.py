"""Pinned native ODR graph with a local corpus exposed via its native MCP API.

No graph, supervisor prompt, tool-selection rule or worker count is patched.
The search corpus is an experiment fixture, not live web retrieval.
"""
import asyncio
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/Liangyijia_Hu/dsh-lab')
OUT = ROOT / 'upstream-runs/odr-qwen-v007-20261030'
QUERY = ('Audit one narrow claim using the supplied official source excerpts: when are new '
         'child executions actually created in Open Deep Research and GPT Researcher, and '
         'how does that differ from optional delegation in DeepSeek Harness? Explain who '
         'creates the work, whether later queries depend on earlier results, and the '
         'difference between a concurrency cap and the total amount of work. '
         'Keep the FINAL report under 600 English words with at most six source citations. '
         'Do not write framework rankings or broad design recommendations. '
         'State evidence gaps briefly instead of speculating. '
         'The source excerpts are ALREADY loaded in the source_search MCP tool available '
         'to your research workers. Retrieve them through the research tools; the user '
         'does not need to supply files or paste text. Do not treat tool-accessible '
         'source material as missing user input.')


def encode(obj):
    if hasattr(obj, 'model_dump'):
        return obj.model_dump(mode='json')
    if hasattr(obj, 'dict'):
        return obj.dict()
    return str(obj)


def serve(port, corpus_dir):
    from mcp.server.fastmcp import FastMCP
    mcp = FastMCP('fixed-official-source-corpus', host='127.0.0.1', port=port,
                  stateless_http=True)
    corpus = [json.loads(p.read_text()) for p in sorted(Path(corpus_dir).glob('*.json'))]

    @mcp.tool()
    def source_search(query: str, max_results: int = 3) -> str:
        """Search exact official source excerpts for ODR, GPT Researcher and DSH.

        This fixed local corpus is not live web search. Returns source URLs and
        literal code with line numbers. Use it to verify orchestration facts.
        """
        words = [w.lower().strip('.,:;()') for w in query.split() if len(w)>3]
        ranked = sorted(corpus, key=lambda row: sum(row['raw_content'].lower().count(w) for w in words), reverse=True)
        return json.dumps(ranked[:max(1,min(max_results,4))], ensure_ascii=False)

    mcp.run(transport='streamable-http')


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    corpus_dir = OUT/'corpus'
    corpus_dir.mkdir()
    import shutil
    for p in (ROOT/'upstream-runs/gptr-qwen-v005-20261030/corpus').glob('*.json'):
        shutil.copy2(p,corpus_dir/p.name)
    document=json.loads((corpus_dir/'01.json').read_text())
    lines=(ROOT/'upstream/open_deep_research/open_deep_research/deep_researcher.py').read_text().splitlines()
    document['raw_content']='\n'.join(f'{i+1}: {lines[i]}' for i in range(281,340))
    (corpus_dir/'01.json').write_text(json.dumps(document,ensure_ascii=False,indent=2))
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0))
        port = sock.getsockname()[1]
    env = dict(os.environ, OPENAI_API_KEY='local-qwen-no-auth',
               OPENAI_BASE_URL='http://127.0.0.1:18083/v1',
               PYTHONPATH=str(ROOT/'upstream/open_deep_research'),
               LANGSMITH_TRACING='false')
    os.environ.update(env)
    sys.path.insert(0, str(ROOT/'upstream/open_deep_research'))
    config = {'configurable': {
        'allow_clarification': False, 'search_api': 'none',
        'max_concurrent_research_units': 3, 'max_researcher_iterations': 3,
        'max_react_tool_calls': 3, 'max_structured_output_retries': 1,
        **{name: 'openai:qwen27b' for name in ['research_model','compression_model','final_report_model','summarization_model']},
        **{name+'_max_tokens':4096 for name in ['research_model','compression_model','final_report_model','summarization_model']},
        'compression_model_max_tokens': 8192,
        'final_report_model_max_tokens': 8192,
        'mcp_config': {'url':f'http://127.0.0.1:{port}', 'tools':['source_search'], 'auth_required':False},
        'mcp_prompt':'source_search searches a fixed local corpus of exact official source excerpts. Use it to verify code facts; this is not live web search.'
    }, 'recursion_limit':80}
    source = ROOT/'upstream/open_deep_research/open_deep_research'
    spec = {'framework':'Open Deep Research', 'source_commit':(source.parent/'SOURCE_COMMIT').read_text().strip(),
            'query':QUERY, 'config':config, 'model':'Qwen3.8-27B',
            'retrieval_mode':'native MCP integration; fixed exact source excerpts; no live web',
            'corpus_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in corpus_dir.glob('*.json')},
            'worker_count_prescribed':False, 'graph_prescribed':False,
            'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.py')}}
    (OUT/'spec.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2))
    with (OUT/'mcp.log').open('w') as log:
        server = subprocess.Popen([sys.executable,__file__,'--mcp',str(port),str(corpus_dir)],env=env,stdout=log,stderr=log)
        try:
            for _ in range(100):
                try:
                    with socket.create_connection(('127.0.0.1',port),timeout=.2):break
                except OSError:time.sleep(.1)
            from open_deep_research.deep_researcher import deep_researcher
            from langchain_core.messages import HumanMessage
            start=time.time()
            completion={'started_wall_time':start,'started_utc':datetime.fromtimestamp(start,timezone.utc).isoformat(),'status':'running'}
            (OUT/'launch.json').write_text(json.dumps(completion,indent=2))
            final={}

            async def execute():
                nonlocal final
                with (OUT/'events.jsonl').open('w') as stream:
                    async for event in deep_researcher.astream_events({'messages':[HumanMessage(content=QUERY)]},config=config,version='v2'):
                        if event['event'].endswith('_stream'):continue
                        row={**event,'wall_time':time.time(),'t':time.time()-start}
                        stream.write(json.dumps(row,ensure_ascii=False,default=encode)+'\n');stream.flush()
                        if event['event']=='on_chain_start' and event['name'] in ['supervisor','researcher','compress_research','final_report_generation']:
                            print(json.dumps({'t':row['t'],'node':event['name'],'event':'start'}),flush=True)
                        if event['event']=='on_chain_end' and not event.get('parent_ids'):
                            final=event['data'].get('output',{})
            try:
                asyncio.run(execute())
                report=final.get('final_report','')
                (OUT/'final-state.json').write_text(json.dumps(final,ensure_ascii=False,indent=2,default=encode))
                (OUT/'report.md').write_text(report)
                completion.update(status='success' if report.strip() and not report.startswith('Error') else 'invalid_report', report_chars=len(report))
            except Exception as exc:
                completion.update(status='error',error=repr(exc),traceback=traceback.format_exc())
            completion.update(finished_wall_time=time.time(),duration_seconds=time.time()-start)
            (OUT/'completion.json').write_text(json.dumps(completion,ensure_ascii=False,indent=2))
            print(json.dumps(completion),flush=True)
        finally:
            server.terminate()
            server.wait(timeout=15)


if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--mcp':serve(int(sys.argv[2]),sys.argv[3])
    else:main()
