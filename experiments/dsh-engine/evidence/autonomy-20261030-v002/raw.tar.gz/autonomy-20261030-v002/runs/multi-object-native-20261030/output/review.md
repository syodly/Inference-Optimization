# Cross-Component Review

Scope: the four independent component dossiers in this directory — `alpha-runtime.md`, `beta-routing.md`, `gamma-tools.md`, `delta-workflow.md`. Each dossier is 4 lines (title, architecture, evidence, risk note). All claims below cite the dossier file they come from.

## Comparison Table

| Component (file) | Architecture | Evidence-backed limitation | Operational consequence |
|---|---|---|---|
| Alpha Runtime (`alpha-runtime.md`) | Queued turn loop with step-boundary input. | Cancellation is checked only at turn boundaries, and a tool result is appended before the next model request; the risk note states long model turns delay newly queued messages. | Messages queued mid-turn are not acted on until the current model turn ends; cancellation of an in-flight turn is not immediate, so user-visible latency grows with turn length. |
| Beta Routing (`beta-routing.md`) | Provider selection merges session defaults with request overrides. | Unsupported reasoning levels are rejected before the provider request; the risk note states inherited defaults can hide a stale route after session restore. | After a session restore, a stale route can be silently inherited from session defaults, so requests may be sent to an unintended provider (or rejected) without any per-request signal that the default is outdated. |
| Gamma Tools (`gamma-tools.md`) | Safe read calls may share a bounded pool; mutations create a barrier. | Tool results are returned in model order even when safe calls overlap; the risk note states the model cannot observe a tool completion before the batch response. | The model cannot react to an early tool result within a batch — it only sees results at the batch boundary — so dependent follow-ups must wait for the slowest call in the batch, and per-call progress is invisible to the model. |
| Delta Workflow (`delta-workflow.md`) | A script fans out child calls and waits for a foreground barrier. | A failed item becomes `null` while a script error fails the whole run; the risk note states foreground workflows hide intermediate child messages from the caller. | Item-level failures are silent (`null`) and must be detected by the caller, while a single script-level error aborts the entire run; additionally the caller sees no intermediate child output until the barrier completes, reducing observability during long runs. |

## Ranked Cross-Component Recommendation

Ranked by severity of the operational consequence and how silently it can fail (most urgent first):

1. **Beta Routing (`beta-routing.md`) — address first.** A stale route inherited after session restore is a *silent correctness* problem: the request goes out (or is rejected) with no per-request indication that the default is outdated. Unlike the other three, the failure mode is not merely latency or observability — it can route work to the wrong provider. Recommendation: make session-restore re-validate inherited route defaults (e.g., re-check provider/reasoning-level support at restore time, as the pre-request rejection of unsupported reasoning levels already does for that one field).
2. **Delta Workflow (`delta-workflow.md`) — second.** Two distinct failure shapes coexist: item failures degrade silently to `null`, while a script error fails the whole run. The blast radius of the script-error path is the largest of the four components (entire run lost), and the hidden intermediate messages mean the caller cannot diagnose which item failed until the barrier. Recommendation: surface item-level `null` results and intermediate child messages to the caller, and isolate script errors so they do not discard completed items.
3. **Gamma Tools (`gamma-tools.md`) — third.** The limitation (model cannot observe a tool completion before the batch response) is a deliberate design trade-off of the bounded pool plus mutation barrier, and the ordering guarantee (results in model order) is a feature, not a bug. The consequence is bounded: latency is capped by the slowest call in a batch. Recommendation: document the batch-boundary semantics for model authors and consider a completion callback or streaming of safe-call results if dependent follow-ups become common.
4. **Alpha Runtime (`alpha-runtime.md`) — fourth.** Long model turns delaying newly queued messages is a latency characteristic of a queued turn loop with step-boundary input; it is predictable, documented in the dossier, and does not corrupt state. Recommendation: expose turn progress or an estimated remaining time to the caller so queued-message delay is visible rather than surprising; no architectural change is indicated by the evidence.

## What Cannot Be Inferred

- **Quantitative impact.** No dossier contains numbers: no queue-delay magnitudes (`alpha-runtime.md`), no pool size or batch-latency figures (`gamma-tools.md`), no fan-out scale or run durations (`delta-workflow.md`), no restore frequency or misroute rate (`beta-routing.md`). Severity ranking above is qualitative.
- **Inter-component interaction.** The dossiers are independent; nothing in any file describes how these four components compose, share state, or fail together. No system-level consequence can be inferred.
- **Mitigations elsewhere.** Each risk note is stated without saying whether it is mitigated by code outside the dossier; the dossiers do not confirm or deny the existence of such mitigations.
- **Production context.** No dossier states deployment status, traffic, user population, or which component is on a critical path.
- **Root causes.** The evidence lines describe observed behavior (e.g., "cancellation is checked at turn boundaries") but not why the design is that way; intent and history cannot be inferred.
- **Completeness.** Each dossier is a single evidence line; absence of a risk in a dossier is not evidence that the component has no other risks.
