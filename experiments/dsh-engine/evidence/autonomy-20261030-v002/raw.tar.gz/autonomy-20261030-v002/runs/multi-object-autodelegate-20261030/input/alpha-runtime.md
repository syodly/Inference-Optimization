Alpha Runtime
Architecture: queued turn loop with step-boundary input.
Evidence: cancellation is checked at turn boundaries; a tool result is appended before the next model request.
Risk note: long model turns delay newly queued messages.
