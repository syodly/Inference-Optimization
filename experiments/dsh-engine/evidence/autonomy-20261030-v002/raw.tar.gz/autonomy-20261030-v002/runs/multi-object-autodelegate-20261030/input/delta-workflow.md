Delta Workflow
Architecture: a script fans out child calls and waits for a foreground barrier.
Evidence: a failed item becomes null while a script error fails the whole run.
Risk note: foreground workflows hide intermediate child messages from the caller.
