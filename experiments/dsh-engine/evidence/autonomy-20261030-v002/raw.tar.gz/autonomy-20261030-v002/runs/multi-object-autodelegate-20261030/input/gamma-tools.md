Gamma Tools
Architecture: safe read calls may share a bounded pool; mutations create a barrier.
Evidence: tool results are returned in model order even when safe calls overlap.
Risk note: the model cannot observe a tool completion before the batch response.
