Beta Routing
Architecture: provider selection merges session defaults with request overrides.
Evidence: unsupported reasoning levels are rejected before the provider request.
Risk note: inherited defaults can hide a stale route after session restore.
