# Cross-Component Review

Scope: the four independent component dossiers in this directory — `alpha-runtime.md`, `beta-routing.md`, `gamma-tools.md`, `delta-workflow.md`. Each dossier is a 4-line self-contained note (title, architecture, evidence, risk note). All claims below are tied to the named file; no dossier file was modified.

## Per-Component Extraction

### Alpha Runtime (`alpha-runtime.md`)
- **Architecture:** queued turn loop with step-boundary input (line 2).
- **Evidence-backed limitation:** cancellation is checked only at turn boundaries, and a tool result is appended before the next model request (line 3). Consequence: anything queued mid-turn — a cancellation or a new user message — cannot be acted on until the current model turn ends.
- **Operational consequence:** long model turns delay newly queued messages (line 4); user-facing responsiveness degrades in proportion to turn length, and cancellation is effectively "best effort at the next boundary."

### Beta Routing (`beta-routing.md`)
- **Architecture:** provider selection merges session defaults with request overrides (line 2).
- **Evidence-backed limitation:** the only documented guard is that unsupported reasoning levels are rejected before the provider request (line 3). That check validates the reasoning level, not the route itself — so after a session restore, inherited defaults can hide a stale route (line 4) and a *valid* request can still be sent to a stale provider.
- **Operational consequence:** after session restore, misrouting is silent for requests that pass the reasoning-level check; the failure mode surfaces only as a rejection when an unsupported reasoning level happens to be used, not as a routing error.

### Gamma Tools (`gamma-tools.md`)
- **Architecture:** safe read calls may share a bounded pool; mutations create a barrier (line 2).
- **Evidence-backed limitation:** tool results are returned in model order even when safe calls overlap (line 3). The model therefore cannot observe an individual tool completion before the batch response (line 4) — it sees nothing until the whole batch is done.
- **Operational consequence:** the model cannot react to an early result within the same batch; a single slow safe read delays visibility of all results in the batch, and dependent calls must wait for the full batch even if their input was ready earlier.

### Delta Workflow (`delta-workflow.md`)
- **Architecture:** a script fans out child calls and waits for a foreground barrier (line 2).
- **Evidence-backed limitation:** a failed item becomes `null` while a script error fails the whole run (line 3). Per-item failure is recoverable (visible as `null`), but a script-level error discards the entire run with no partial results, and the foreground barrier hides intermediate child messages from the caller (line 4).
- **Operational consequence:** the caller cannot observe or steer children mid-run; a single script bug loses all fan-out work, and per-item failures are only visible after the barrier completes.

## Comparison Table

| Component (file) | Architecture | Evidence-backed limitation | Operational consequence |
|---|---|---|---|
| Alpha Runtime (`alpha-runtime.md`) | Queued turn loop, step-boundary input | Cancellation checked only at turn boundaries; tool result appended before next model request | Long model turns delay newly queued messages; cancellation waits for next boundary |
| Beta Routing (`beta-routing.md`) | Provider selection merges session defaults with request overrides | Pre-request check only rejects unsupported reasoning levels; inherited defaults can hide a stale route after session restore | Silent misrouting of valid requests after restore; failure surfaces only as a reasoning-level rejection |
| Gamma Tools (`gamma-tools.md`) | Safe reads share a bounded pool; mutations create a barrier | Results returned in model order even when safe calls overlap; no per-call completion visible to the model | Model cannot react to early results; one slow read delays the whole batch's visibility |
| Delta Workflow (`delta-workflow.md`) | Script fans out child calls, waits at a foreground barrier | Failed item → `null`, but a script error fails the whole run; intermediate child messages hidden from caller | No mid-run observability or steering; a script bug loses all fan-out work |

## Ranked Cross-Component Recommendation

Ranking criteria (stated explicitly, since the dossiers give no quantitative data): worst-case severity first (work loss > silent misbehavior > latency), then detectability (silent > explicit). This is a judgment call, not a measured priority.

1. **Delta Workflow (`delta-workflow.md`)** — highest priority. A script error fails the whole run (line 3), i.e. total loss of all fan-out work, and the foreground barrier hides intermediate child messages (line 4), so the caller cannot detect or mitigate mid-run. Recommend: make script errors non-fatal per item (or checkpoint partial results) and expose child progress to the caller.
2. **Beta Routing (`beta-routing.md`)** — silent misrouting after session restore (line 4) is the only failure mode here that can produce wrong results without any error signal; the documented guard (line 3) does not cover it. Recommend: validate or refresh the effective route on session restore, and surface the resolved route to the caller.
3. **Alpha Runtime (`alpha-runtime.md`)** — latency-class issue: long turns delay queued messages (line 4) and cancellation waits for a boundary (line 3). No data loss. Recommend: mid-turn cancellation checkpoints or a turn-length bound.
4. **Gamma Tools (`gamma-tools.md`)** — latency/efficiency-class issue: the model cannot observe completions before the batch response (line 4). No data loss, and the bounded pool (line 2) already caps concurrency. Recommend: per-call result streaming, or let dependent calls wait on a specific result rather than the whole batch.

Ranks 3 and 4 are close; both are latency-class with no data loss, and either could be ordered first depending on whether user-facing responsiveness (Alpha) or model efficiency (Gamma) matters more in the deployment.

## What Cannot Be Inferred

- **No quantitative data.** The dossiers contain no measurements — no turn lengths, pool sizes, queue depths, failure rates, or latencies. Severity statements above are qualitative.
- **No scale assumptions.** Nothing in the files states a number of workers, children, or concurrent calls; none is assumed here.
- **No interaction model.** The dossiers are independent; nothing documents how these four components compose in a real system, so no end-to-end bottleneck or cross-component failure path can be inferred.
- **No root causes or history.** The risk notes (line 4 of each file) are not identified as known bugs, design trade-offs, or open issues; their status cannot be inferred.
- **No deployment context.** No versions, environments, test coverage, or operational history are present, so no claim about current production behavior is possible.
- **Evidence lines are single observations.** Each "Evidence" line (line 3 of each file) is one stated fact, not a measured dataset; frequency and magnitude of the associated risk cannot be inferred from it.
