# Fact-Check Report

**Date:** 2026-10-29
**Scope:** Answers to the six questions in `questions.md`, grounded exclusively in the supplied source collection under `sources/` (10 documents per question, `d0.md`–`d9.md`).
**Method:** Every source file in each question's collection was read in full. Each answer below cites the specific files that support it, and notes any missing or conflicting evidence, including distractor documents that describe similarly named but different entities.

---

## Q1. Mick Carter is the landlord of a public house located at what address?

**Answer: 46 Albert Square, Walford, London E20** (the fictional address of The Queen Victoria public house in *EastEnders*).

**Supporting evidence:**
- `sources/q1/d2.md` (Mick Carter): "Mick immediately becomes the new landlord of The Queen Victoria public house (referred to as 'The Vic')."
- `sources/q1/d3.md` (The Queen Victoria): "The Queen Victoria (more often referred to as The Queen Vic or The Vic) is the Victorian public house in the BBC soap opera, 'EastEnders'. It has the fictional address of 46 Albert Square, Walford, London E20."
- Corroborating context: `sources/q1/d6.md` (Linda Carter) confirms the Carter family took over The Queen Victoria ("Linda became landlady of The Queen Victoria public house"), and `sources/q1/d7.md` / `sources/q1/d9.md` (Whitney Dean, Nancy Carter) confirm the Carter family's association with the pub.

**Missing/conflicting evidence:** None. The address is explicitly stated in `d3.md` and is unambiguous. Note that the address is fictional (Walford is the fictional setting of *EastEnders*). The remaining files in the collection (`d0.md` Fat Cat Brewery, `d1.md` The Gatehouse Monmouth, `d4.md` Shakespeare Public House Bristol, `d5.md` Square and Compass, `d8.md` Adam & Eve Birmingham) describe unrelated real-world pubs and do not mention Mick Carter.

---

## Q2. "Heropanti" star Kriti Sanon appears in the remix video for a song from what Bollywood film?

**Answer: *Agent Vinod*** (the song is "Raabta").

**Supporting evidence:**
- `sources/q2/d3.md` (Raabta, song): "'Raabta' (English: Relation) is a romantic Hindi song from the 2012 Bollywood film, 'Agent Vinod'. … the remix video of the song stars Deepika Padukone, Sushant Singh Rajput, Kriti Sanon and Jim Sarbh from the film Raabta."
- `sources/q2/d8.md` (Kriti Sanon) and `sources/q2/d6.md` (Heropanti) confirm that Kriti Sanon is a "Heropanti" star (her Hindi film debut, released 23 May 2014).

**Missing/conflicting evidence:** No direct conflict, but one near-miss distractor should be noted: `sources/q2/d9.md` (Main Tera Boyfriend) states that song's *music video* stars Kriti Sanon and Sushant Singh Rajput and that it is from the film *Raabta* — but that is a music video, not a remix video, and the question specifically asks about a remix video. The only source describing a remix video featuring Kriti Sanon is `d3.md`, which ties it to *Agent Vinod*. The other files (`d0.md` Dohchay, `d1.md` Sabbir Khan, `d2.md` Raabta film, `d4.md` Raat Bhar, `d5.md` 1: Nenokkadine, `d7.md` Bareilly Ki Barfi) describe other films/songs and do not mention a remix video.

---

## Q3. Which restaurant was founded first, Papa Murphy's or Gino's Pizza and Spaghetti?

**Answer: Gino's Pizza and Spaghetti** (founded 1961, vs. Papa Murphy's 1995).

**Supporting evidence:**
- `sources/q3/d3.md` (Gino's Pizza and Spaghetti): "The company was founded by Kenney Grant in 1961."
- `sources/q3/d7.md` (Papa Murphy's): "It began in 1995 as the merger of two take-and-bake pizza companies: Papa Aldo's Pizza (founded in 1981) and Murphy's Pizza (founded in 1981)."

**Missing/conflicting evidence:** No conflict. Even counting the 1981 founding of Papa Murphy's predecessor companies, Gino's Pizza and Spaghetti (1961) still predates it. One naming trap in the collection: `sources/q3/d0.md` describes **Gino's Hamburgers** (founded 1957 in Baltimore) — a different chain from Gino's Pizza and Spaghetti, so it does not affect the answer. The remaining files (`d1.md` Tudor's Biscuit World, `d2.md` Papa Murphy's Park, `d4.md` Sacramento Republic FC, `d5.md` Papa Gino's, `d6.md` Gino's East, `d8.md` Spencer Park, `d9.md` Pizza 73) are unrelated distractors.

---

## Q4. Who was most well-known as a radio personality and disc jockey, John Garabedian or Charles A. Agemian?

**Answer: John Garabedian.**

**Supporting evidence:**
- `sources/q4/d9.md` (John Garabedian): "John H. Garabedian is an American radio personality and disc jockey … He is best known as the creator and former long-time host of 'Open House Party'."
- `sources/q4/d8.md` (Open House Party): "The show started in 1987, and was hosted by John Garabedian from September 1987 to January 2017. Garabedian created the show."
- `sources/q4/d3.md` (XY TV): "It was wholly owned by American radio personality John Garabedian."
- `sources/q4/d7.md` (Charles A. Agemian): describes him as "an American banker" (executive vice president of operations at Chase Manhattan Bank, later CEO of Hackensack Trust Co.). The source contains **no mention of radio or disc jockey work** for Agemian.

**Missing/conflicting evidence:** No conflict. The evidence is one-sided: three sources describe Garabedian as a radio personality/DJ, while the only source on Agemian describes him solely as a banker. The other files (`d0.md` Don Sherwood, `d1.md` M.G. Kelly, `d2.md` At Your Request, `d4.md` Radio personality, `d5.md` Lin Brehmer, `d6.md` Big Wilson) concern other radio personalities or the general concept, and are not relevant to the two named individuals.

---

## Q5. What football team did Mario Gomez and Javi Martinez both play for?

**Answer: FC Bayern Munich.**

**Supporting evidence:**
- `sources/q5/d8.md` (Mario Gómez): "Gómez joined Fiorentina after spending four seasons with Bayern Munich, which he joined after six years playing for VfB Stuttgart."
- `sources/q5/d7.md` (Javi Martínez): "… is a Spanish footballer who plays for German club FC Bayern Munich as a defensive midfielder or a central defender."
- `sources/q5/d5.md` (2012–13 FC Bayern Munich season): "Bayern also added holding midfielder Javi Martínez after the first week of the Bundesliga season at the transfer deadline."

**Missing/conflicting evidence:** No conflict. The sources do not state the exact overlapping years, but both players' Bayern Munich stints are independently documented (Gómez: four seasons; Martínez: signed 2012, per `d5.md` and `d7.md`). One distractor to note: `sources/q5/d4.md` describes **Willie Martinez**, an American football *coach* — a different person from Javi Martínez. The remaining files (`d0.md` D.C. Armor, `d1.md` England women's U23, `d2.md` Kentucky Xtreme, `d3.md` Tate Forcier, `d6.md` 2012 FIU Panthers, `d9.md` 1993 Auburn Tigers) are unrelated.

---

## Q6. Were Goo Goo Dolls and Echosmith formed in the same city?

**Answer: No.** Goo Goo Dolls were formed in **Buffalo, New York**; Echosmith were formed in **Chino, California**.

**Supporting evidence:**
- `sources/q6/d5.md` (Goo Goo Dolls): "The Goo Goo Dolls are an American rock band formed in 1985 in Buffalo, New York, by vocalist and guitarist John Rzeznik, vocalist and bassist Robby Takac, and drummer George Tutuska."
- `sources/q6/d0.md` (Echosmith): "Echosmith is an American, Corporate indie pop band formed in February 2009 in Chino, California."

**Missing/conflicting evidence:** No conflict. The two formation cities are explicitly stated and clearly different. The remaining files in the collection (`d1.md` All That You Are, `d2.md` Live in Buffalo, `d3.md` Goo Goo Dolls album, `d4.md` Notbroken, `d6.md` Something for the Rest of Us, `d7.md` Waiting for the Rest of It, `d8.md` iTunes Originals, `d9.md` Hold Me Up) concern Goo Goo Dolls releases and do not contradict the formation city.

---

## Summary Table

| # | Question (short) | Answer | Key sources |
|---|------------------|--------|-------------|
| 1 | Mick Carter's pub address | 46 Albert Square, Walford, London E20 (The Queen Victoria, *EastEnders*) | `q1/d2.md`, `q1/d3.md` |
| 2 | Film of the song whose remix video features Kriti Sanon | *Agent Vinod* (song: "Raabta") | `q2/d3.md` |
| 3 | Founded first: Papa Murphy's or Gino's Pizza and Spaghetti | Gino's Pizza and Spaghetti (1961 vs. 1995) | `q3/d3.md`, `q3/d7.md` |
| 4 | More well-known radio personality/DJ | John Garabedian | `q4/d9.md`, `q4/d8.md`, `q4/d7.md` |
| 5 | Team shared by Mario Gomez and Javi Martinez | FC Bayern Munich | `q5/d8.md`, `q5/d7.md`, `q5/d5.md` |
| 6 | Same formation city? | No — Buffalo, NY vs. Chino, CA | `q6/d5.md`, `q6/d0.md` |

**Overall assessment:** All six questions are answerable from the supplied sources with no unresolved conflicts. The main evidentiary caveats are: (a) the Q1 address is explicitly fictional; (b) Q2 requires distinguishing a *remix* video (d3.md) from a regular music video (d9.md); (c) Q3 contains a similarly named but distinct chain (Gino's Hamburgers, d0.md) that does not affect the answer; and (d) Q5 contains a different person with a similar name (Willie Martinez, d4.md).
