"""Inventory reservations must be atomic, and quantities must be positive."""


def reserve(stock, request):
    for sku, quantity in request.items():
        if not isinstance(quantity, int) or isinstance(quantity, bool) or quantity <= 0:
            raise ValueError('quantity must be a positive integer')
        if stock.get(sku, 0) < quantity:
            raise ValueError('insufficient stock')
    for sku, quantity in request.items():
        stock[sku] -= quantity
    return stock
