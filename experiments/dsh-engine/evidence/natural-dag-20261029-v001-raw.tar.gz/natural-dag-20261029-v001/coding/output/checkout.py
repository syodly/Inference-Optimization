"""An order key identifies its original successful result even on retries."""
from inventory import reserve
from pricing import total


class Checkout:
    def __init__(self, stock):
        self.stock = dict(stock)
        self.completed = {}

    def submit(self, key, items, prices, discount='0', tax='0'):
        if key in self.completed:
            return self.completed[key]
        amount = total([(prices[sku], quantity) for sku, quantity in items.items()], discount, tax)
        reserve(self.stock, items)
        result = {'order_key': key, 'amount': str(amount)}
        self.completed[key] = result
        return result
