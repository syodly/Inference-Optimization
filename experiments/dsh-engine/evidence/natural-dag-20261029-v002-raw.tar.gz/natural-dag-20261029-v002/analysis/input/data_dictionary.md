# Revenue definitions

Amounts are USD. These are curated test data.
Orders may contain exact repeated order_id delivery events; count each order_id once. Only status=paid contributes quantity times products.unit_price. Refunds are dollar amounts; deduplicate by refund_id and attribute each refund to its original paid order month. Net revenue equals paid gross revenue minus unique refunds. Product mix uses paid orders only.
