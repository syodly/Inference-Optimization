# February vs January Net Revenue — Reconciliation Report

**Scope:** Reconcile `orders.csv`, `refunds.csv`, and `products.csv` per the definitions in
`data_dictionary.md`, and explain why February 2026 net revenue differs from January 2026.

**Reproducibility:** Run `python3 analyze.py` in this directory. It applies the dictionary
rules (dedupe orders by `order_id`, count only `status=paid`, dedupe refunds by
`refund_id`, attribute refunds to the original paid order's month) and prints the tables
below plus a machine-readable `summary.json`. Totals were independently cross-checked with
a separate awk implementation; both agree exactly.

## 1. Monthly totals (USD)

| Month    | Paid orders | Cancelled | Gross revenue | Refunds | **Net revenue** |
|----------|------------:|----------:|--------------:|--------:|----------------:|
| 2026-01  | 44          | 4         | 8,480.00      | 140.00  | **8,340.00**    |
| 2026-02  | 44          | 4         | 2,900.00      | 200.00  | **2,700.00**    |
| Change   | 0           | 0         | −5,580.00 (−65.8%) | +60.00 | **−5,640.00 (−67.6%)** |

Net revenue = paid gross revenue − unique refunds, per the data dictionary.

## 2. Main drivers of the difference

**Order volume is identical (44 paid orders in each month), so the entire decline is a
product-mix / price effect, not a volume effect.**

### 2.1 Product mix (paid orders only)

| Product | Category   | Unit price | Jan units | Feb units | Jan revenue | Feb revenue | Δ revenue |
|---------|------------|-----------:|----------:|----------:|------------:|------------:|----------:|
| p1      | Starter    | $20        | 23        | 75        | 460.00      | 1,500.00    | +1,040.00 |
| p2      | Pro        | $60        | 22        | 0         | 1,320.00    | 0.00        | −1,320.00 |
| p3      | Team       | $100       | 21        | 14        | 2,100.00    | 1,400.00    | −700.00   |
| p4      | Enterprise | $200       | 23        | 0         | 4,600.00    | 0.00        | −4,600.00 |
| **Total** |          |            | **89**    | **89**    | **8,480.00**| **2,900.00**| **−5,580.00** |

Decomposition of the −$5,580 gross-revenue change:

1. **p4 (Enterprise, $200) disappeared in February: −$4,600** — the single largest driver
   (82% of the gross decline). In January it was 54.2% of gross revenue.
2. **p2 (Pro, $60) disappeared in February: −$1,320** (24% of the gross decline).
3. **p3 (Team, $100) volume fell 21 → 14 units: −$700.**
4. **p1 (Starter, $20) volume rose 23 → 75 units: +$1,040** — the only positive
   contribution, but it cannot offset the loss of the two higher-priced tiers.

In short: February's paid orders consist only of the two cheapest tiers (p1 and p3);
the mid (p2) and top (p4) tiers had zero paid orders, while January sold all four tiers
in roughly equal unit counts.

### 2.2 Refunds (secondary driver)

Unique refunds rose from $140 (Jan) to $200 (Feb), a +$60 additional drag (~1% of the net
change). Refund detail (deduplicated, attributed to the original paid order's month):

| Refund | Order  | Month   | Amount |
|--------|--------|---------|-------:|
| r1     | o1005  | 2026-01 | 20.00  |
| r2     | o1011  | 2026-01 | 100.00 |
| r3     | o1024  | 2026-01 | 20.00  |
| r4     | o2002  | 2026-02 | 20.00  |
| r5     | o2007  | 2026-02 | 60.00  |
| r6     | o2014  | 2026-02 | 20.00  |
| r7     | o2023  | 2026-02 | 100.00 |

Every refund references an existing **paid** order, so all are validly attributed.

## 3. Data quality issues

1. **Duplicate order rows (exact repeats of the same delivery event):**
   - `o1005` — line 98 repeats line 7
   - `o2001` — line 99 repeats line 51
   - `o2012` — line 100 repeats line 62

   Per the data dictionary, each `order_id` is counted once. If these had been counted
   naively, January gross would be overstated by $180 and February gross by $140.
2. **Duplicate refund row (exact repeat):** `r7` — line 9 repeats line 8. Counted once;
   a naive count would overstate February refunds by $100.
3. **No other issues found:** all `product_id` values exist in `products.csv`; all
   `paid_date` values fall in the expected months; all refunds reference existing paid
   orders (no orphan or non-paid references); no conflicting (non-identical) duplicate
   rows.
4. **Minor formatting note:** the CSV files use CRLF line endings; handled transparently
   by the analysis (Python `csv` module) and by the awk cross-check after stripping `\r`.

### Impact of deduplication (for reference)

| Scenario            | Jan net | Feb net | Net change |
|---------------------|--------:|--------:|-----------:|
| Correct (deduped)   | 8,340   | 2,700   | −5,640     |
| Naive (duplicates counted) | 8,520 | 2,600 | −5,920 |

Deduplication changes the month-over-month net change by $280 but does not change the
conclusion: the decline is driven by the absence of p2/p4 sales in February.

## 4. Conclusion

February net revenue ($2,700) is $5,640 (−67.6%) below January ($8,340). With paid order
counts identical (44 each), the difference is almost entirely a **product-mix shift**:
February had zero paid orders for the Pro ($60) and Enterprise ($200) tiers, which
together contributed $5,920 (70%) of January's gross revenue, while the Starter tier
volume tripled and only partially offset the loss. A small additional drag came from
higher refunds (+$60). The supplied data contains four exact duplicate rows (3 orders,
1 refund) that were deduplicated per the data dictionary; no other data quality issues
were found.
