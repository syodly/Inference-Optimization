#!/usr/bin/env python3
"""Reproducible reconciliation of January vs February net revenue.

Rules (from data_dictionary.md):
  * Amounts are USD.
  * Orders may contain exact repeated order_id delivery events; count each
    order_id once.
  * Only status=paid contributes quantity * products.unit_price.
  * Refunds are dollar amounts; deduplicate by refund_id and attribute each
    refund to its original paid order month.
  * Net revenue = paid gross revenue - unique refunds.
  * Product mix uses paid orders only.

Run:  python3 analyze.py
"""

import csv
import sys
from collections import Counter, defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent
MONTHS = ("2026-01", "2026-02")


def load_csv(name):
    with open(BASE / name, newline="") as f:
        return list(csv.DictReader(f))


def main():
    products = {r["product_id"]: r for r in load_csv("products.csv")}
    order_rows = load_csv("orders.csv")
    refund_rows = load_csv("refunds.csv")

    dq = []  # data quality findings

    # ---- Orders: deduplicate by order_id --------------------------------
    seen = {}
    dup_orders = []
    for i, row in enumerate(order_rows, start=2):  # line numbers incl. header
        oid = row["order_id"]
        if oid in seen:
            first = seen[oid]
            if first[1] == row:
                dup_orders.append((oid, "exact duplicate row", i))
            else:
                dup_orders.append((oid, "CONFLICTING duplicate row", i))
                dq.append(f"CONFLICT: order {oid} has differing duplicate rows "
                          f"(line {first[0]} vs line {i}): {first[1]} vs {row}")
        else:
            seen[oid] = (i, row)

    orders = [row for _, row in seen.values()]
    if dup_orders:
        dq.append("Duplicate order rows (exact repeats, counted once per "
                  "order_id per data dictionary): "
                  + ", ".join(f"{oid} (line {ln})" for oid, kind, ln in dup_orders))

    # ---- Refunds: deduplicate by refund_id ------------------------------
    seen_r = {}
    dup_refunds = []
    for i, row in enumerate(refund_rows, start=2):
        rid = row["refund_id"]
        if rid in seen_r:
            first = seen_r[rid]
            if first[1] == row:
                dup_refunds.append((rid, i))
            else:
                dq.append(f"CONFLICT: refund {rid} has differing duplicate rows "
                          f"(line {first[0]} vs line {i})")
        else:
            seen_r[rid] = (i, row)

    refunds = [row for _, row in seen_r.values()]
    if dup_refunds:
        dq.append("Duplicate refund rows (exact repeats, counted once per "
                  "refund_id per data dictionary): "
                  + ", ".join(f"{rid} (line {ln})" for rid, ln in dup_refunds))

    # ---- Validation ------------------------------------------------------
    paid_orders = []
    for row in orders:
        pid = row["product_id"]
        if pid not in products:
            dq.append(f"Order {row['order_id']} references unknown product {pid}")
            continue
        if row["status"] != "paid":
            continue
        paid_orders.append(row)

    paid_ids = {r["order_id"] for r in paid_orders}
    for row in refunds:
        oid = row["order_id"]
        if oid not in {r["order_id"] for r in orders}:
            dq.append(f"Refund {row['refund_id']} references unknown order {oid}")
        elif oid not in paid_ids:
            orig = next(r for r in orders if r["order_id"] == oid)
            dq.append(f"Refund {row['refund_id']} references non-paid order {oid} "
                      f"(status={orig['status']}); excluded from net revenue")

    # ---- Monthly aggregation --------------------------------------------
    gross = defaultdict(float)
    refund_total = defaultdict(float)
    mix = defaultdict(Counter)          # month -> product -> units
    mix_rev = defaultdict(Counter)      # month -> product -> revenue
    paid_count = Counter()
    cancelled_count = Counter()

    for row in orders:
        month = row["paid_date"][:7]
        if row["status"] == "paid":
            paid_count[month] += 1
            price = float(products[row["product_id"]]["unit_price"])
            qty = int(row["quantity"])
            rev = qty * price
            gross[month] += rev
            mix[month][row["product_id"]] += qty
            mix_rev[month][row["product_id"]] += rev
        else:
            cancelled_count[month] += 1

    for row in refunds:
        oid = row["order_id"]
        orig = next((r for r in orders if r["order_id"] == oid), None)
        if orig is not None and orig["status"] == "paid":
            refund_total[orig["paid_date"][:7]] += float(row["amount"])

    # ---- Report ----------------------------------------------------------
    print("=" * 62)
    print("MONTHLY REVENUE RECONCILIATION (USD)")
    print("=" * 62)
    header = f"{'month':<10}{'paid':>6}{'cancelled':>10}{'gross':>10}{'refunds':>10}{'net':>10}"
    print(header)
    print("-" * len(header))
    net = {}
    for m in MONTHS:
        net[m] = gross[m] - refund_total[m]
        print(f"{m:<10}{paid_count[m]:>6}{cancelled_count[m]:>10}"
              f"{gross[m]:>10.2f}{refund_total[m]:>10.2f}{net[m]:>10.2f}")

    jan, feb = MONTHS
    print("-" * len(header))
    print(f"Change Jan -> Feb: gross {gross[feb] - gross[jan]:+.2f} "
          f"({(gross[feb] - gross[jan]) / gross[jan] * 100:+.1f}%), "
          f"refunds {refund_total[feb] - refund_total[jan]:+.2f}, "
          f"net {net[feb] - net[jan]:+.2f} "
          f"({(net[feb] - net[jan]) / net[jan] * 100:+.1f}%)")

    print()
    print("PRODUCT MIX (paid orders only)")
    print("-" * len(header))
    all_pids = sorted(products)
    print(f"{'product':<10}{'price':>8}" + "".join(f"{m + ' qty':>12}" for m in MONTHS)
          + "".join(f"{m + ' rev':>12}" for m in MONTHS))
    for pid in all_pids:
        line = f"{pid:<10}{float(products[pid]['unit_price']):>8.0f}"
        for m in MONTHS:
            line += f"{mix[m][pid]:>12}"
        for m in MONTHS:
            line += f"{mix_rev[m][pid]:>12.2f}"
        print(line)

    print()
    print("REFUND DETAIL (deduplicated, attributed to paid order month)")
    print("-" * len(header))
    for row in sorted(refunds, key=lambda r: r["refund_id"]):
        orig = next(r for r in orders if r["order_id"] == row["order_id"])
        print(f"{row['refund_id']:<6} order {row['order_id']:<7} "
              f"month {orig['paid_date'][:7]}  amount {float(row['amount']):>8.2f}")

    print()
    print("DATA QUALITY FINDINGS")
    print("-" * len(header))
    if dq:
        for i, d in enumerate(dq, 1):
            print(f"{i}. {d}")
    else:
        print("None.")

    # Machine-readable summary for the report
    summary = {
        "months": {
            m: {
                "paid_orders": paid_count[m],
                "cancelled_orders": cancelled_count[m],
                "gross_revenue": gross[m],
                "refunds": refund_total[m],
                "net_revenue": net[m],
                "units_by_product": dict(mix[m]),
                "revenue_by_product": dict(mix_rev[m]),
            } for m in MONTHS
        },
        "data_quality": dq,
    }
    import json
    (BASE / "summary.json").write_text(json.dumps(summary, indent=2))
    print()
    print("Wrote summary.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
