1. Mick Carter is the landlord of a public house located at what address? (source collection: sources/q1/)

2. "Heropanti" star Kriti Sanon appears in the remix video for a song from what Bollywood film? (source collection: sources/q2/)

3. Which restaurant was founded first, Papa Murphy's or Gino's Pizza and Spaghetti? (source collection: sources/q3/)

4. Who was most well-known as a radio personality and disc jockey, John Garabedian or Charles A. Agemian? (source collection: sources/q4/)

5. What football team did Mario Gomez and Javi Martinez both play for? (source collection: sources/q5/)

6. Were Goo Goo Dolls and Echosmith formed in the same city? (source collection: sources/q6/)
