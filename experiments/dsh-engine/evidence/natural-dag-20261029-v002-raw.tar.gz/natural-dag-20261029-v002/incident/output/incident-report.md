# Incident Report: Checkout Outage — 2026-10-28

**Status:** Root cause identified (high confidence)
**Impact window:** 2026-10-28 09:04 UTC → ongoing at end of supplied data (09:15 UTC)
**Impact:** Checkout error rate 0.3% → 8%, p95 latency 180 ms → 4200 ms (504s at the edge). Payments service unaffected.

---

## 1. Evidence inventory

| Source | File | What it provides |
|---|---|---|
| Ticket | `ticket.md` | Onset "shortly after 09:04 UTC"; two changes that morning (edge release, checkout deployment) |
| Deploy history | `deployments.log` | Timestamps of edge v4.11 deploy/rollback and checkout v2.18 rollout, incl. the pool config change |
| Metrics | `metrics.csv` | Per-minute rps, error %, checkout p95, DB active connections / waiters / CPU, payment p95 |
| Checkout app log | `logs/checkout.log` | Per-request outcome: `db_wait_ms` before, `database connection acquisition timeout; queue_wait_ms=4000` after |
| Database log | `logs/database.log` | DB-side health: `active`, `query_p95_ms`, `lock_waiters`, and `FATAL remaining connection slots are reserved` |
| Edge log | `logs/edge.log` | Upstream status/latency per request (200/180 ms before, 504/4200 ms after) |
| Payments log | `logs/payments.log` | Payment service health (healthy throughout) |
| Config history | `config/checkout-before.json`, `config/checkout-after.json` | Only diff: `database_pool_max_per_replica` 12 → 24 |

All timestamps are UTC.

---

## 2. Timestamped causal timeline

All entries below are **facts** from the supplied evidence unless marked *(hypothesis)*.

| Time (UTC) | Event | Evidence |
|---|---|---|
| 08:58 | **Edge v4.11 deployed** — "routing rules unchanged; adds request-id response header". Baseline remains healthy (100 rps, 0.3% errors, checkout p95 180 ms, DB active=75, waiters=0, DB CPU 30%, payment p95 28 ms). | `deployments.log` L1; `metrics.csv` L2–L7; all logs 08:58–09:03 |
| 09:03 | **Checkout v2.18 rollout begins**; config change `database_pool_max_per_replica` 12 → 24. Metrics still healthy at this minute. | `deployments.log` L2; `config/checkout-*.json`; `metrics.csv` L7 |
| 09:04 | **Checkout v2.18 rollout complete (replicas=6).** In the same minute: error % 0.3 → **8**, checkout p95 180 → **4200 ms**, DB active connections 75 → **100**, DB connection waiters 0 → **24**. DB CPU flat (30 → 31%), DB `query_p95_ms` flat (9 ms), `lock_waiters=0`. | `deployments.log` L3; `metrics.csv` L8; `logs/database.log` L7 |
| 09:04 | Checkout requests begin failing with **`database connection acquisition timeout; queue_wait_ms=4000; payment not called`** — requests die while waiting for a DB connection, before any payment call. | `logs/checkout.log` L7–L18 |
| 09:04 | Database begins logging **`FATAL remaining connection slots are reserved; active=100`** — the DB is at its connection cap and rejecting new connections. Query performance itself is unchanged (p95 9 ms, no lock waiters). | `logs/database.log` L7–L18 |
| 09:04 | Edge begins returning **504s at 4200 ms** for checkout upstream — consistent with the 4000 ms connection-queue timeout plus overhead. | `logs/edge.log` L7–L18 |
| 09:04–09:15 | Failure state is **steady**: 8% errors, 4200 ms p95, DB pinned at active=100 with 24 waiters, every checkout request timing out on connection acquisition. Traffic constant at 100 rps. Payments service healthy the entire window (p95 28 ms, 0 errors). | `metrics.csv` L8–L19; `logs/checkout.log`; `logs/payments.log` |
| 09:10 | **Edge v4.11 rolled back.** "checkout timeouts persist" — the edge change is exonerated. | `deployments.log` L4 |

---

## 3. Root cause analysis

### Most likely root cause (high confidence)

**The checkout v2.18 deployment raised `database_pool_max_per_replica` from 12 to 24, making the fleet-wide pool ceiling (6 replicas × 24 = 144) exceed the database's `max_connections` (100, of which 18 are used by other clients, leaving 82 for checkout). The pool demanded more connections than the database could grant; the DB hit its cap and rejected new connections, and checkout requests queued for a connection until the 4000 ms acquisition timeout, producing 504s.**

Capacity math (facts from `config/checkout-before.json` / `checkout-after.json`):

| | Before (v2.17) | After (v2.18) |
|---|---|---|
| Replicas | 6 | 6 |
| Pool max per replica | 12 | **24** |
| Fleet pool ceiling | 6 × 12 = **72** | 6 × 24 = **144** |
| DB `max_connections` | 100 | 100 |
| Other clients | 18 | 18 |
| Connections available to checkout | 100 − 18 = **82** | 100 − 18 = **82** |
| Headroom | 72 ≤ 82 ✅ (10 spare) | 144 > 82 ❌ (62 over) |

Corroborating evidence:

1. **Temporal correlation (fact):** the failure begins in the exact minute the rollout completed (09:04), after a healthy 09:03 minute during which the rollout was in progress.
2. **Failure mode matches the mechanism (fact):** checkout fails at *connection acquisition* (`queue_wait_ms=4000`), not at query execution; the DB is simultaneously at `active=100` (its cap) logging `FATAL remaining connection slots are reserved` — the classic PostgreSQL message when `max_connections` is exhausted and only superuser-reserved slots remain.
3. **The database is healthy, not slow (fact):** `query_p95_ms` stays at 9 ms, `lock_waiters=0`, DB CPU flat at ~30%. This is connection *saturation*, not query degradation.
4. **Downstream is exonerated (fact):** payments are healthy throughout, and checkout logs confirm `payment not called` — requests never reached the payment step.
5. **Edge is exonerated (fact):** edge v4.11 was rolled back at 09:10 and "checkout timeouts persist" (`deployments.log` L4). Edge routing rules were unchanged, and the edge 504s are upstream-originated.
6. **No traffic change (fact):** rps constant at 100 across the whole window — this is not a load spike.

*(Hypothesis — mechanism detail not directly observable in the data:)* why the pool grew to the new maximum at rollout time. Plausible triggers: the new pool size caused pools to pre-open/grow connections on replica startup, or the new version holds connections longer per request. The supplied data does not distinguish these; the capacity arithmetic above holds regardless of which trigger fired.

### Plausible alternatives considered and ruled out

| Alternative | Verdict | Why |
|---|---|---|
| **Edge v4.11 release** | Ruled out (fact) | Rolled back at 09:10; timeouts persisted. Routing rules unchanged; edge 504s are upstream-originated (4200 ms ≈ 4000 ms checkout queue timeout + overhead). |
| **Database degradation** (slow queries, lock contention, CPU) | Ruled out (fact) | `query_p95_ms` flat at 9 ms, `lock_waiters=0`, DB CPU 30% → 31%. The DB is healthy but connection-saturated. |
| **Payment service failure** | Ruled out (fact) | `payments.log` healthy the entire window (p95 28 ms, 0 errors); checkout requests failed *before* calling payments. |
| **Traffic spike / load increase** | Ruled out (fact) | `requests_per_second` constant at 100 from 08:58 to 09:15. |
| **Checkout v2.18 code change (new/slower queries)** | Unlikely | DB query p95 did not change (9 ms) and failures occur at connection acquisition, before query execution. The only config diff in the same deployment (pool 12 → 24) fully explains the observed saturation. *(Residual hypothesis: a code change could have increased connection hold time, which would compound the pool change — not distinguishable from the supplied data.)* |
| **Other clients (18) consuming the DB** | Not the cause | Other clients were present and constant before and after; the pre-change budget (72 + 18 = 90 ≤ 100) had headroom. The change that broke the budget was the pool doubling. |

---

## 4. Mitigation plan

### Immediate (restore service)

1. **Roll back checkout to v2.17**, or hot-patch the config `database_pool_max_per_replica` 24 → 12 (equivalent: restore the 72-connection fleet ceiling, which fits the 82 available).
   - If hot-patching: apply the config change and recycle replicas so pools shrink; verify no stale connections remain (see verification).
2. **Confirm the database is not left with orphaned connections** after rollback: check `pg_stat_activity` for checkout connections above the expected 72 and terminate stragglers if present.

### Short term (prevent recurrence)

3. **Add a deploy-time capacity guard:** reject any checkout config where `replicas × database_pool_max_per_replica + other_clients > database_max_connections` (recommend enforcing ≤ 80% of `max_connections` to leave headroom for other clients and growth).
4. **Alert on DB connection pressure:** `db_connection_waiters > 0` sustained for 1–2 minutes, and `db_active_connections / max_connections > 0.8`. The 09:04 waiters=24 signal would have paged before customer impact.
5. **Canary/progressive rollout with automated rollback** on SLO breach (error % or p95), so a bad config change is caught on one replica, not six.

### Longer term (structural)

6. **Introduce a connection pooler (e.g., PgBouncer in transaction mode)** between checkout and the database, decapping app-side pool sizes from the DB's `max_connections` and making per-replica pool settings safe to tune independently.
7. **Treat `database_max_connections` as a shared budget** with an explicit, documented allocation (checkout vs. other clients) reviewed at every capacity change.

---

## 5. Verification plan

**Post-rollback (production), monitor for ≥ 15 minutes:**

| Check | Expected (baseline) | Source |
|---|---|---|
| `error_percent` | ≤ 0.5% (baseline 0.3%) | `metrics.csv` |
| `checkout_p95_ms` | ≤ 200 ms (baseline 180 ms) | `metrics.csv` |
| `db_active_connections` | ≤ 75 (baseline 75) | `metrics.csv` |
| `db_connection_waiters` | 0 | `metrics.csv` |
| `db_cpu_percent` | ~30% | `metrics.csv` |
| Checkout log | `completed db_wait_ms≈3`, no `connection acquisition timeout` | `logs/checkout.log` |
| Database log | No `FATAL remaining connection slots are reserved` | `logs/database.log` |
| Edge log | `upstream_status=200`, latency ≈ 180 ms | `logs/edge.log` |
| Payments log | Remains healthy (control) | `logs/payments.log` |

**Pre-deployment (staging), before re-attempting any pool increase:**

1. **Reproduce the failure deterministically:** deploy with `database_pool_max_per_replica=24` against a DB with `max_connections=100`, `other_clients=18`; confirm the same signature (DB at cap, `FATAL` reserved-slots messages, 4000 ms acquisition timeouts, 504s). This validates the root-cause model.
2. **Verify the guard:** attempt the same config through the deploy pipeline with the capacity guard in place; confirm it is rejected.
3. **Verify the fix at scale:** with the pooler (or corrected budget) in place, run load at ≥ 100 rps and confirm `db_connection_waiters=0` and p95 ≤ 200 ms with headroom.

---

## 6. Facts vs. hypotheses — summary

**Facts (directly from supplied evidence):**
- Edge v4.11 deployed 08:58, rolled back 09:10; checkout v2.18 rolled out 09:03–09:04 with pool 12 → 24.
- Failure began at 09:04: 8% errors, 4200 ms p95, DB active=100, waiters=24; steady through 09:15.
- Checkout failures are DB connection-acquisition timeouts (4000 ms queue wait), before payment calls.
- DB logged `FATAL remaining connection slots are reserved` at active=100 while query p95 (9 ms), lock waiters (0), and CPU (~30%) stayed flat.
- Payments healthy throughout; traffic constant at 100 rps; edge rollback did not restore service.
- Config diff is exactly one field: `database_pool_max_per_replica` 12 → 24; fleet ceiling 144 > DB cap 100 (82 available to checkout).

**Hypotheses (inferred, not directly observable):**
- The pool grew to the new maximum at rollout time (pre-open on startup vs. demand-driven growth — not distinguishable from the data).
- A v2.18 code change may have increased connection hold time, compounding the pool change (not distinguishable; the config change alone is sufficient to explain the saturation).
- The exact reason the DB rejected connections at 100 rather than 100−reserved is the standard PostgreSQL superuser-reserved-slot behavior (inferred from the FATAL message text).
