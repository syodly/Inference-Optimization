import sys, random
sys.path.insert(0, '/home/Liangyijia_Hu/dsh-public-task-workspaces/public-tasks-20261030-v001/lcb-abc387_c')
from snake import count_leq

def is_snake(n):
    s = str(n)
    return int(s[0]) > max(int(c) for c in s[1:])

def brute(L, R):
    return sum(1 for n in range(L, R+1) if is_snake(n))

random.seed(42)
for _ in range(300):
    L = random.randint(10, 300000)
    R = random.randint(L, L + random.randint(0, 80000))
    b = brute(L, R)
    f = count_leq(R) - count_leq(L-1)
    assert b == f, (L, R, b, f)
print("all ok")
