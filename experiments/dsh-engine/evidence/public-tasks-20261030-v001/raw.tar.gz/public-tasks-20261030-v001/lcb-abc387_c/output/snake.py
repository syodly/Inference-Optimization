import sys

def count_leq(N):
    if N < 10:
        return 0
    s = str(N)
    d = len(s)
    digits = [int(c) for c in s]
    total = 0
    # shorter lengths
    for dd in range(2, d):
        total += sum(a ** (dd - 1) for a in range(1, 10))
    # same length, leading digit smaller
    for a in range(1, digits[0]):
        total += a ** (d - 1)
    # same length, leading digit equal
    a = digits[0]
    cnt = 0
    done = False
    for i in range(1, d):
        ni = digits[i]
        if ni > a - 1:
            cnt += a ** (d - i)
            done = True
            break
        cnt += ni * a ** (d - 1 - i)
    if not done:
        cnt += 1
    total += cnt
    return total

def main():
    L, R = map(int, sys.stdin.read().split())
    print(count_leq(R) - count_leq(L - 1))

if __name__ == "__main__":
    main()
