A positive integer not less than 10 whose top digit (the most significant digit) in decimal representation is strictly larger than every other digit in that number is called a Snake number.
For example, 31 and 201 are Snake numbers, but 35 and 202 are not.
Find how many Snake numbers exist between L and R, inclusive.

Input

The input is given from Standard Input in the following format:
L R

Output

Print the answer.

Constraints


- 10 \leq L \leq R \leq 10^{18}
- All input values are integers.

Sample Input 1

97 210

Sample Output 1

6

The Snake numbers between 97 and 210, inclusive, are 97, 98, 100, 200, 201, and 210: there are six.

Sample Input 2

1000 9999

Sample Output 2

2025

Sample Input 3

252509054433933519 760713016476190692

Sample Output 3

221852052834757